#include <sys/time.h>
#include <vector>
#include "dbtoaster/functions.hpp"
#include "dbtoaster/hash.hpp"
#include "dbtoaster/macro.hpp"
#include "dbtoaster/mmap.hpp"
#include "dbtoaster/serialization.hpp"
#include "dbtoaster/types.hpp"
#include "common.hpp"



#define RELATION_G1_DYNAMIC
#define RELATION_G2_DYNAMIC
#define RELATION_G3_DYNAMIC
#define RELATION_G4_DYNAMIC

namespace dbtoaster {

  /* Definitions of maps used for storing materialized views. */
  struct G1_entry {
    int32_t a; int32_t b; int64_t __av; G1_entry* nxt; G1_entry* prv;
  
    explicit G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit G1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { a = c0; b = c1; __av = c2;  }
    G1_entry(const G1_entry& other) : a(other.a), b(other.b), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        a = std::stoi(f[0]); b = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct G2_entry {
    int32_t a; int32_t c; int64_t __av; G2_entry* nxt; G2_entry* prv;
  
    explicit G2_entry() : nxt(nullptr), prv(nullptr) { }
    explicit G2_entry(const int32_t c0, const int32_t c1, const int64_t c2) { a = c0; c = c1; __av = c2;  }
    G2_entry(const G2_entry& other) : a(other.a), c(other.c), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    G2_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        a = std::stoi(f[0]); c = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct G3_entry {
    int32_t a; int32_t d; int64_t __av; G3_entry* nxt; G3_entry* prv;
  
    explicit G3_entry() : nxt(nullptr), prv(nullptr) { }
    explicit G3_entry(const int32_t c0, const int32_t c1, const int64_t c2) { a = c0; d = c1; __av = c2;  }
    G3_entry(const G3_entry& other) : a(other.a), d(other.d), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    G3_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        a = std::stoi(f[0]); d = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, d);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct G4_entry {
    int32_t a; int32_t e; int64_t __av; G4_entry* nxt; G4_entry* prv;
  
    explicit G4_entry() : nxt(nullptr), prv(nullptr) { }
    explicit G4_entry(const int32_t c0, const int32_t c1, const int64_t c2) { a = c0; e = c1; __av = c2;  }
    G4_entry(const G4_entry& other) : a(other.a), e(other.e), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    G4_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        a = std::stoi(f[0]); e = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, e);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  struct V_A_GGGG1_entry {
    int32_t A; int64_t __av; V_A_GGGG1_entry* nxt; V_A_GGGG1_entry* prv;
  
    explicit V_A_GGGG1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_A_GGGG1_entry(const int32_t c0, const int64_t c1) { A = c0; __av = c1;  }
    V_A_GGGG1_entry(const V_A_GGGG1_entry& other) : A(other.A), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_A_GGGG1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        A = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_A_GGGG1_entry& modify(const int32_t c0) { A = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, A);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_A_GGGG1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_A_GGGG1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.A);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_A_GGGG1_entry& x, const V_A_GGGG1_entry& y) {
      return x.A == y.A;
    }
  };
  
  typedef MultiHashMap<V_A_GGGG1_entry, int64_t, 
    PrimaryHashIndex<V_A_GGGG1_entry, V_A_GGGG1_mapkey0_idxfn>
  > V_A_GGGG1_map;
  
  
  struct V_B_G1_entry {
    int32_t A; int64_t __av; V_B_G1_entry* nxt; V_B_G1_entry* prv;
  
    explicit V_B_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_B_G1_entry(const int32_t c0, const int64_t c1) { A = c0; __av = c1;  }
    V_B_G1_entry(const V_B_G1_entry& other) : A(other.A), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_B_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        A = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_B_G1_entry& modify(const int32_t c0) { A = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, A);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_B_G1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_B_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.A);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_B_G1_entry& x, const V_B_G1_entry& y) {
      return x.A == y.A;
    }
  };
  
  typedef MultiHashMap<V_B_G1_entry, int64_t, 
    PrimaryHashIndex<V_B_G1_entry, V_B_G1_mapkey0_idxfn>
  > V_B_G1_map;
  
  
  struct V_C_G1_entry {
    int32_t A; int64_t __av; V_C_G1_entry* nxt; V_C_G1_entry* prv;
  
    explicit V_C_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_C_G1_entry(const int32_t c0, const int64_t c1) { A = c0; __av = c1;  }
    V_C_G1_entry(const V_C_G1_entry& other) : A(other.A), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_C_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        A = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_C_G1_entry& modify(const int32_t c0) { A = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, A);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_C_G1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_C_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.A);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_C_G1_entry& x, const V_C_G1_entry& y) {
      return x.A == y.A;
    }
  };
  
  typedef MultiHashMap<V_C_G1_entry, int64_t, 
    PrimaryHashIndex<V_C_G1_entry, V_C_G1_mapkey0_idxfn>
  > V_C_G1_map;
  
  
  struct V_D_G1_entry {
    int32_t A; int64_t __av; V_D_G1_entry* nxt; V_D_G1_entry* prv;
  
    explicit V_D_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_D_G1_entry(const int32_t c0, const int64_t c1) { A = c0; __av = c1;  }
    V_D_G1_entry(const V_D_G1_entry& other) : A(other.A), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_D_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        A = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_D_G1_entry& modify(const int32_t c0) { A = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, A);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_D_G1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_D_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.A);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_D_G1_entry& x, const V_D_G1_entry& y) {
      return x.A == y.A;
    }
  };
  
  typedef MultiHashMap<V_D_G1_entry, int64_t, 
    PrimaryHashIndex<V_D_G1_entry, V_D_G1_mapkey0_idxfn>
  > V_D_G1_map;
  
  
  struct V_E_G1_entry {
    int32_t A; int64_t __av; V_E_G1_entry* nxt; V_E_G1_entry* prv;
  
    explicit V_E_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_E_G1_entry(const int32_t c0, const int64_t c1) { A = c0; __av = c1;  }
    V_E_G1_entry(const V_E_G1_entry& other) : A(other.A), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_E_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        A = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_E_G1_entry& modify(const int32_t c0) { A = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, A);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_E_G1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_E_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.A);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_E_G1_entry& x, const V_E_G1_entry& y) {
      return x.A == y.A;
    }
  };
  
  typedef MultiHashMap<V_E_G1_entry, int64_t, 
    PrimaryHashIndex<V_E_G1_entry, V_E_G1_mapkey0_idxfn>
  > V_E_G1_map;
  
  
  struct TMP_SUM1_entry {
    int32_t A; int64_t __av; TMP_SUM1_entry* nxt; TMP_SUM1_entry* prv;
  
    explicit TMP_SUM1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM1_entry(const int32_t c0, const int64_t c1) { A = c0; __av = c1;  }
    TMP_SUM1_entry(const TMP_SUM1_entry& other) : A(other.A), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        A = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM1_entry& modify(const int32_t c0) { A = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, A);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.A);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM1_entry& x, const TMP_SUM1_entry& y) {
      return x.A == y.A;
    }
  };
  
  typedef MultiHashMap<TMP_SUM1_entry, int64_t, 
    PrimaryHashIndex<TMP_SUM1_entry, TMP_SUM1_mapkey0_idxfn>
  > TMP_SUM1_map;
  
  
  struct TMP_SUM2_entry {
    int32_t A; int64_t __av; TMP_SUM2_entry* nxt; TMP_SUM2_entry* prv;
  
    explicit TMP_SUM2_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM2_entry(const int32_t c0, const int64_t c1) { A = c0; __av = c1;  }
    TMP_SUM2_entry(const TMP_SUM2_entry& other) : A(other.A), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM2_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        A = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM2_entry& modify(const int32_t c0) { A = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, A);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM2_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM2_entry& e) {
      size_t h = 0;
      hash_combine(h, e.A);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM2_entry& x, const TMP_SUM2_entry& y) {
      return x.A == y.A;
    }
  };
  
  typedef MultiHashMap<TMP_SUM2_entry, int64_t, 
    PrimaryHashIndex<TMP_SUM2_entry, TMP_SUM2_mapkey0_idxfn>
  > TMP_SUM2_map;
  
  
  struct TMP_SUM3_entry {
    int32_t A; int64_t __av; TMP_SUM3_entry* nxt; TMP_SUM3_entry* prv;
  
    explicit TMP_SUM3_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM3_entry(const int32_t c0, const int64_t c1) { A = c0; __av = c1;  }
    TMP_SUM3_entry(const TMP_SUM3_entry& other) : A(other.A), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM3_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        A = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM3_entry& modify(const int32_t c0) { A = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, A);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM3_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM3_entry& e) {
      size_t h = 0;
      hash_combine(h, e.A);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM3_entry& x, const TMP_SUM3_entry& y) {
      return x.A == y.A;
    }
  };
  
  typedef MultiHashMap<TMP_SUM3_entry, int64_t, 
    PrimaryHashIndex<TMP_SUM3_entry, TMP_SUM3_mapkey0_idxfn>
  > TMP_SUM3_map;
  
  
  struct TMP_SUM4_entry {
    int32_t A; int64_t __av; TMP_SUM4_entry* nxt; TMP_SUM4_entry* prv;
  
    explicit TMP_SUM4_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM4_entry(const int32_t c0, const int64_t c1) { A = c0; __av = c1;  }
    TMP_SUM4_entry(const TMP_SUM4_entry& other) : A(other.A), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM4_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        A = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM4_entry& modify(const int32_t c0) { A = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, A);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM4_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM4_entry& e) {
      size_t h = 0;
      hash_combine(h, e.A);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM4_entry& x, const TMP_SUM4_entry& y) {
      return x.A == y.A;
    }
  };
  
  typedef MultiHashMap<TMP_SUM4_entry, int64_t, 
    PrimaryHashIndex<TMP_SUM4_entry, TMP_SUM4_mapkey0_idxfn>
  > TMP_SUM4_map;
  
  
  struct DELTA_G1_entry {
    int32_t a; int32_t b; int64_t __av; DELTA_G1_entry* nxt; DELTA_G1_entry* prv;
  
    explicit DELTA_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_G1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { a = c0; b = c1; __av = c2;  }
    DELTA_G1_entry(const DELTA_G1_entry& other) : a(other.a), b(other.b), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        a = std::stoi(f[0]); b = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_G1_entry& modify(const int32_t c0, const int32_t c1) { a = c0; b = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_G1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.a);
      hash_combine(h, e.b);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_G1_entry& x, const DELTA_G1_entry& y) {
      return x.a == y.a && x.b == y.b;
    }
  };
  
  typedef MultiHashMap<DELTA_G1_entry, int64_t, 
    PrimaryHashIndex<DELTA_G1_entry, DELTA_G1_mapkey01_idxfn>
  > DELTA_G1_map;
  
  
  struct DELTA_G2_entry {
    int32_t a; int32_t c; int64_t __av; DELTA_G2_entry* nxt; DELTA_G2_entry* prv;
  
    explicit DELTA_G2_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_G2_entry(const int32_t c0, const int32_t c1, const int64_t c2) { a = c0; c = c1; __av = c2;  }
    DELTA_G2_entry(const DELTA_G2_entry& other) : a(other.a), c(other.c), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_G2_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        a = std::stoi(f[0]); c = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_G2_entry& modify(const int32_t c0, const int32_t c1) { a = c0; c = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_G2_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_G2_entry& e) {
      size_t h = 0;
      hash_combine(h, e.a);
      hash_combine(h, e.c);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_G2_entry& x, const DELTA_G2_entry& y) {
      return x.a == y.a && x.c == y.c;
    }
  };
  
  typedef MultiHashMap<DELTA_G2_entry, int64_t, 
    PrimaryHashIndex<DELTA_G2_entry, DELTA_G2_mapkey01_idxfn>
  > DELTA_G2_map;
  
  
  struct DELTA_G3_entry {
    int32_t a; int32_t d; int64_t __av; DELTA_G3_entry* nxt; DELTA_G3_entry* prv;
  
    explicit DELTA_G3_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_G3_entry(const int32_t c0, const int32_t c1, const int64_t c2) { a = c0; d = c1; __av = c2;  }
    DELTA_G3_entry(const DELTA_G3_entry& other) : a(other.a), d(other.d), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_G3_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        a = std::stoi(f[0]); d = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_G3_entry& modify(const int32_t c0, const int32_t c1) { a = c0; d = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, d);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_G3_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_G3_entry& e) {
      size_t h = 0;
      hash_combine(h, e.a);
      hash_combine(h, e.d);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_G3_entry& x, const DELTA_G3_entry& y) {
      return x.a == y.a && x.d == y.d;
    }
  };
  
  typedef MultiHashMap<DELTA_G3_entry, int64_t, 
    PrimaryHashIndex<DELTA_G3_entry, DELTA_G3_mapkey01_idxfn>
  > DELTA_G3_map;
  
  
  struct DELTA_G4_entry {
    int32_t a; int32_t e; int64_t __av; DELTA_G4_entry* nxt; DELTA_G4_entry* prv;
  
    explicit DELTA_G4_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_G4_entry(const int32_t c0, const int32_t c1, const int64_t c2) { a = c0; e = c1; __av = c2;  }
    DELTA_G4_entry(const DELTA_G4_entry& other) : a(other.a), e(other.e), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_G4_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        a = std::stoi(f[0]); e = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_G4_entry& modify(const int32_t c0, const int32_t c1) { a = c0; e = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, e);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_G4_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_G4_entry& e) {
      size_t h = 0;
      hash_combine(h, e.a);
      hash_combine(h, e.e);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_G4_entry& x, const DELTA_G4_entry& y) {
      return x.a == y.a && x.e == y.e;
    }
  };
  
  typedef MultiHashMap<DELTA_G4_entry, int64_t, 
    PrimaryHashIndex<DELTA_G4_entry, DELTA_G4_mapkey01_idxfn>
  > DELTA_G4_map;

  

  /* Defines top-level materialized views */
  struct tlq_t {
    struct timeval t0, t; 
    size_t tT, tN, tS;
  
    tlq_t(): tN(0), tS(0)  { 
      gettimeofday(&t0, NULL); 
    }
  
    /* Serialization code */
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << "\n";
      const V_A_GGGG1_map& _V_A_GGGG1 = get_V_A_GGGG1();
      dbtoaster::serialize_nvp_tabbed(ar, STRING(V_A_GGGG1), _V_A_GGGG1, "\t");
    }
  
    /* Functions returning / computing the results of top level queries */
    const V_A_GGGG1_map& get_V_A_GGGG1() const {
      return V_A_GGGG1;
    }
  
  protected:
    /* Data structures used for storing / computing top-level queries */
    V_A_GGGG1_map V_A_GGGG1;
    
  };

  /* Contains materialized views and processing (IVM) logic */
  struct data_t : tlq_t {
  
    data_t(): tlq_t() {
      
      
    }
  
    
  
    
  
    /* Trigger functions for table relations */
    
    
    /* Trigger functions for stream relations */
    void on_batch_update_G1(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM1.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& a = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& b = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v1 = chunk.payload[i];
          TMP_SUM1.addOrDelOnZero(se1.modify(a), v1);
        }
      }
      
      { //foreach
        TMP_SUM1_entry* e2 = TMP_SUM1.head;
        while (e2) {
          int32_t a = e2->A;
          int64_t v2 = e2->__av;
          V_A_GGGG1.addOrDelOnZero(se2.modify(a), (((v2 * V_C_G1.getValueOrDefault(se3.modify(a))) * V_D_G1.getValueOrDefault(se4.modify(a))) * V_E_G1.getValueOrDefault(se5.modify(a))));
          e2 = e2->nxt;
        }
      }
      
      { //foreach
        TMP_SUM1_entry* e3 = TMP_SUM1.head;
        while (e3) {
          int32_t a = e3->A;
          int64_t v3 = e3->__av;
          V_B_G1.addOrDelOnZero(se6.modify(a), v3);
          e3 = e3->nxt;
        }
      }
    }
    
    
    void on_batch_update_G2(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM2.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& a = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v4 = chunk.payload[i];
          TMP_SUM2.addOrDelOnZero(se7.modify(a), v4);
        }
      }
      
      { //foreach
        TMP_SUM2_entry* e5 = TMP_SUM2.head;
        while (e5) {
          int32_t a = e5->A;
          int64_t v5 = e5->__av;
          V_A_GGGG1.addOrDelOnZero(se8.modify(a), (((v5 * V_D_G1.getValueOrDefault(se9.modify(a))) * V_E_G1.getValueOrDefault(se10.modify(a))) * V_B_G1.getValueOrDefault(se11.modify(a))));
          e5 = e5->nxt;
        }
      }
      
      { //foreach
        TMP_SUM2_entry* e6 = TMP_SUM2.head;
        while (e6) {
          int32_t a = e6->A;
          int64_t v6 = e6->__av;
          V_C_G1.addOrDelOnZero(se12.modify(a), v6);
          e6 = e6->nxt;
        }
      }
    }
    
    
    void on_batch_update_G3(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM3.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& a = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& d = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v7 = chunk.payload[i];
          TMP_SUM3.addOrDelOnZero(se13.modify(a), v7);
        }
      }
      
      { //foreach
        TMP_SUM3_entry* e8 = TMP_SUM3.head;
        while (e8) {
          int32_t a = e8->A;
          int64_t v8 = e8->__av;
          V_A_GGGG1.addOrDelOnZero(se14.modify(a), (((v8 * V_E_G1.getValueOrDefault(se15.modify(a))) * V_C_G1.getValueOrDefault(se16.modify(a))) * V_B_G1.getValueOrDefault(se17.modify(a))));
          e8 = e8->nxt;
        }
      }
      
      { //foreach
        TMP_SUM3_entry* e9 = TMP_SUM3.head;
        while (e9) {
          int32_t a = e9->A;
          int64_t v9 = e9->__av;
          V_D_G1.addOrDelOnZero(se18.modify(a), v9);
          e9 = e9->nxt;
        }
      }
    }
    
    
    void on_batch_update_G4(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM4.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& a = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& e = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v10 = chunk.payload[i];
          TMP_SUM4.addOrDelOnZero(se19.modify(a), v10);
        }
      }
      
      { //foreach
        TMP_SUM4_entry* e11 = TMP_SUM4.head;
        while (e11) {
          int32_t a = e11->A;
          int64_t v11 = e11->__av;
          V_A_GGGG1.addOrDelOnZero(se20.modify(a), (((v11 * V_D_G1.getValueOrDefault(se21.modify(a))) * V_C_G1.getValueOrDefault(se22.modify(a))) * V_B_G1.getValueOrDefault(se23.modify(a))));
          e11 = e11->nxt;
        }
      }
      
      { //foreach
        TMP_SUM4_entry* e12 = TMP_SUM4.head;
        while (e12) {
          int32_t a = e12->A;
          int64_t v12 = e12->__av;
          V_E_G1.addOrDelOnZero(se24.modify(a), v12);
          e12 = e12->nxt;
        }
      }
    }
    
    
    void on_system_ready_event() {
      
    }
  
  private:
    
      /* Preallocated map entries (to avoid recreation of temporary objects) */
      TMP_SUM1_entry se1;
      V_A_GGGG1_entry se2;
      V_C_G1_entry se3;
      V_D_G1_entry se4;
      V_E_G1_entry se5;
      V_B_G1_entry se6;
      TMP_SUM2_entry se7;
      V_A_GGGG1_entry se8;
      V_D_G1_entry se9;
      V_E_G1_entry se10;
      V_B_G1_entry se11;
      V_C_G1_entry se12;
      TMP_SUM3_entry se13;
      V_A_GGGG1_entry se14;
      V_E_G1_entry se15;
      V_C_G1_entry se16;
      V_B_G1_entry se17;
      V_D_G1_entry se18;
      TMP_SUM4_entry se19;
      V_A_GGGG1_entry se20;
      V_D_G1_entry se21;
      V_C_G1_entry se22;
      V_B_G1_entry se23;
      V_E_G1_entry se24;
    
      
    
      /* Data structures used for storing materialized views */
      V_B_G1_map V_B_G1;
      V_C_G1_map V_C_G1;
      V_D_G1_map V_D_G1;
      V_E_G1_map V_E_G1;
      TMP_SUM1_map TMP_SUM1;
      TMP_SUM2_map TMP_SUM2;
      TMP_SUM3_map TMP_SUM3;
      TMP_SUM4_map TMP_SUM4;
      DELTA_G1_map DELTA_G1;
      DELTA_G2_map DELTA_G2;
      DELTA_G3_map DELTA_G3;
      DELTA_G4_map DELTA_G4;
    
      
    
  };

  

  namespace Config {
    static const std::vector<DataSourceConfig> DataSources = {
    {
      "G1",
      true,
      DataSourceType::CSV,
      "unused.g1",
      // schema
      {{"a", PrimitiveType::INT32}, {"b", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_G1(chunk);
      }
    },
    {
      "G2",
      true,
      DataSourceType::CSV,
      "unused.g2",
      // schema
      {{"a", PrimitiveType::INT32}, {"c", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_G2(chunk);
      }
    },
    {
      "G3",
      true,
      DataSourceType::CSV,
      "unused.g3",
      // schema
      {{"a", PrimitiveType::INT32}, {"d", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_G3(chunk);
      }
    },
    {
      "G4",
      true,
      DataSourceType::CSV,
      "unused.g4",
      // schema
      {{"a", PrimitiveType::INT32}, {"e", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_G4(chunk);
      }
    }
    };
  }

}