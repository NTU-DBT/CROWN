#include <sys/time.h>
#include <vector>
#include "dbtoaster/functions.hpp"
#include "dbtoaster/hash.hpp"
#include "dbtoaster/macro.hpp"
#include "dbtoaster/mmap.hpp"
#include "dbtoaster/serialization.hpp"
#include "dbtoaster/types.hpp"
#include "common.hpp"

#include "ring/ring_factorized.hpp"

#define RELATION_G1_DYNAMIC
#define RELATION_G2_DYNAMIC
#define RELATION_G3_DYNAMIC
#define RELATION_V1_DYNAMIC
#define RELATION_V2_DYNAMIC

namespace dbtoaster {

  /* Definitions of maps used for storing materialized views. */
  struct G1_entry {
    int32_t a; int32_t b; int64_t __av; G1_entry* nxt; G1_entry* prv;
  
    explicit G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit G1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { a = c0; b = c1; __av = c2;  }
    G1_entry(const G1_entry& other) : a(other.a), b(other.b), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        a = std::stoi(f[0]); b = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct G2_entry {
    int32_t b; int32_t c; int64_t __av; G2_entry* nxt; G2_entry* prv;
  
    explicit G2_entry() : nxt(nullptr), prv(nullptr) { }
    explicit G2_entry(const int32_t c0, const int32_t c1, const int64_t c2) { b = c0; c = c1; __av = c2;  }
    G2_entry(const G2_entry& other) : b(other.b), c(other.c), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    G2_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        b = std::stoi(f[0]); c = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct G3_entry {
    int32_t c; int32_t d; int64_t __av; G3_entry* nxt; G3_entry* prv;
  
    explicit G3_entry() : nxt(nullptr), prv(nullptr) { }
    explicit G3_entry(const int32_t c0, const int32_t c1, const int64_t c2) { c = c0; d = c1; __av = c2;  }
    G3_entry(const G3_entry& other) : c(other.c), d(other.d), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    G3_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        c = std::stoi(f[0]); d = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, d);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V1_entry {
    int32_t a; int64_t __av; V1_entry* nxt; V1_entry* prv;
  
    explicit V1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V1_entry(const int32_t c0, const int64_t c1) { a = c0; __av = c1;  }
    V1_entry(const V1_entry& other) : a(other.a), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        a = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V2_entry {
    int32_t d; int64_t __av; V2_entry* nxt; V2_entry* prv;
  
    explicit V2_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V2_entry(const int32_t c0, const int64_t c1) { d = c0; __av = c1;  }
    V2_entry(const V2_entry& other) : d(other.d), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V2_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        d = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, d);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  struct V_A_GV1_entry {
    int32_t B; RingFactorizedRelation<1, int32_t> __av; V_A_GV1_entry* nxt; V_A_GV1_entry* prv;
  
    explicit V_A_GV1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_A_GV1_entry(const int32_t c0, const RingFactorizedRelation<1, int32_t>& c1) { B = c0; __av = c1;  }
    V_A_GV1_entry(const V_A_GV1_entry& other) : B(other.B), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_A_GV1_entry(const std::vector<std::string>& f, const RingFactorizedRelation<1, int32_t>& v) {
        /* if (f.size() < 1) return; */
        B = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_A_GV1_entry& modify(const int32_t c0) { B = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_A_GV1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_A_GV1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_A_GV1_entry& x, const V_A_GV1_entry& y) {
      return x.B == y.B;
    }
  };
  
  typedef MultiHashMap<V_A_GV1_entry, RingFactorizedRelation<1, int32_t>, 
    PrimaryHashIndex<V_A_GV1_entry, V_A_GV1_mapkey0_idxfn>
  > V_A_GV1_map;
  
  
  struct V_G1_G1_entry {
    int32_t A; int32_t B; int64_t __av; V_G1_G1_entry* nxt; V_G1_G1_entry* prv;
  
    explicit V_G1_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_G1_G1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { A = c0; B = c1; __av = c2;  }
    V_G1_G1_entry(const V_G1_G1_entry& other) : A(other.A), B(other.B), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_G1_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        A = std::stoi(f[0]); B = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_G1_G1_entry& modify(const int32_t c0, const int32_t c1) { A = c0; B = c1;  return *this; }
    FORCE_INLINE V_G1_G1_entry& modify0(const int32_t c0) { A = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, A);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_G1_G1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const V_G1_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.A);
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_G1_G1_entry& x, const V_G1_G1_entry& y) {
      return x.A == y.A && x.B == y.B;
    }
  };
  
  struct V_G1_G1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_G1_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.A);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_G1_G1_entry& x, const V_G1_G1_entry& y) {
      return x.A == y.A;
    }
  };
  
  typedef MultiHashMap<V_G1_G1_entry, int64_t, 
    PrimaryHashIndex<V_G1_G1_entry, V_G1_G1_mapkey01_idxfn>,
    SecondaryHashIndex<V_G1_G1_entry, V_G1_G1_mapkey0_idxfn>
  > V_G1_G1_map;
  
  
  struct V_V1_V1_entry {
    int32_t A; int64_t __av; V_V1_V1_entry* nxt; V_V1_V1_entry* prv;
  
    explicit V_V1_V1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_V1_V1_entry(const int32_t c0, const int64_t c1) { A = c0; __av = c1;  }
    V_V1_V1_entry(const V_V1_V1_entry& other) : A(other.A), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_V1_V1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        A = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_V1_V1_entry& modify(const int32_t c0) { A = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, A);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_V1_V1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_V1_V1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.A);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_V1_V1_entry& x, const V_V1_V1_entry& y) {
      return x.A == y.A;
    }
  };
  
  typedef MultiHashMap<V_V1_V1_entry, int64_t, 
    PrimaryHashIndex<V_V1_V1_entry, V_V1_V1_mapkey0_idxfn>
  > V_V1_V1_map;
  
  
  struct V_C_GVG1_entry {
    int32_t B; RingFactorizedRelation<2, int32_t> __av; V_C_GVG1_entry* nxt; V_C_GVG1_entry* prv;
  
    explicit V_C_GVG1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_C_GVG1_entry(const int32_t c0, const RingFactorizedRelation<2, int32_t>& c1) { B = c0; __av = c1;  }
    V_C_GVG1_entry(const V_C_GVG1_entry& other) : B(other.B), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_C_GVG1_entry(const std::vector<std::string>& f, const RingFactorizedRelation<2, int32_t>& v) {
        /* if (f.size() < 1) return; */
        B = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_C_GVG1_entry& modify(const int32_t c0) { B = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_C_GVG1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_C_GVG1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_C_GVG1_entry& x, const V_C_GVG1_entry& y) {
      return x.B == y.B;
    }
  };
  
  typedef MultiHashMap<V_C_GVG1_entry, RingFactorizedRelation<2, int32_t>, 
    PrimaryHashIndex<V_C_GVG1_entry, V_C_GVG1_mapkey0_idxfn>
  > V_C_GVG1_map;
  
  
  struct V_D_GV1_entry {
    int32_t C; RingFactorizedRelation<3, int32_t> __av; V_D_GV1_entry* nxt; V_D_GV1_entry* prv;
  
    explicit V_D_GV1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_D_GV1_entry(const int32_t c0, const RingFactorizedRelation<3, int32_t>& c1) { C = c0; __av = c1;  }
    V_D_GV1_entry(const V_D_GV1_entry& other) : C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_D_GV1_entry(const std::vector<std::string>& f, const RingFactorizedRelation<3, int32_t>& v) {
        /* if (f.size() < 1) return; */
        C = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_D_GV1_entry& modify(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_D_GV1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_D_GV1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_D_GV1_entry& x, const V_D_GV1_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<V_D_GV1_entry, RingFactorizedRelation<3, int32_t>, 
    PrimaryHashIndex<V_D_GV1_entry, V_D_GV1_mapkey0_idxfn>
  > V_D_GV1_map;
  
  
  struct V_G3_G1_entry {
    int32_t C; int32_t D; int64_t __av; V_G3_G1_entry* nxt; V_G3_G1_entry* prv;
  
    explicit V_G3_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_G3_G1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { C = c0; D = c1; __av = c2;  }
    V_G3_G1_entry(const V_G3_G1_entry& other) : C(other.C), D(other.D), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_G3_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        C = std::stoi(f[0]); D = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_G3_G1_entry& modify(const int32_t c0, const int32_t c1) { C = c0; D = c1;  return *this; }
    FORCE_INLINE V_G3_G1_entry& modify1(const int32_t c1) { D = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, D);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_G3_G1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const V_G3_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      hash_combine(h, e.D);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_G3_G1_entry& x, const V_G3_G1_entry& y) {
      return x.C == y.C && x.D == y.D;
    }
  };
  
  struct V_G3_G1_mapkey1_idxfn {
    FORCE_INLINE static size_t hash(const V_G3_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.D);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_G3_G1_entry& x, const V_G3_G1_entry& y) {
      return x.D == y.D;
    }
  };
  
  typedef MultiHashMap<V_G3_G1_entry, int64_t, 
    PrimaryHashIndex<V_G3_G1_entry, V_G3_G1_mapkey01_idxfn>,
    SecondaryHashIndex<V_G3_G1_entry, V_G3_G1_mapkey1_idxfn>
  > V_G3_G1_map;
  
  
  struct V_V2_V1_entry {
    int32_t D; int64_t __av; V_V2_V1_entry* nxt; V_V2_V1_entry* prv;
  
    explicit V_V2_V1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_V2_V1_entry(const int32_t c0, const int64_t c1) { D = c0; __av = c1;  }
    V_V2_V1_entry(const V_V2_V1_entry& other) : D(other.D), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_V2_V1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        D = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_V2_V1_entry& modify(const int32_t c0) { D = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, D);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_V2_V1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_V2_V1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.D);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_V2_V1_entry& x, const V_V2_V1_entry& y) {
      return x.D == y.D;
    }
  };
  
  typedef MultiHashMap<V_V2_V1_entry, int64_t, 
    PrimaryHashIndex<V_V2_V1_entry, V_V2_V1_mapkey0_idxfn>
  > V_V2_V1_map;
  
  
  struct V_G2_G1_entry {
    int32_t B; int32_t C; int64_t __av; V_G2_G1_entry* nxt; V_G2_G1_entry* prv;
  
    explicit V_G2_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_G2_G1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { B = c0; C = c1; __av = c2;  }
    V_G2_G1_entry(const V_G2_G1_entry& other) : B(other.B), C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_G2_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        B = std::stoi(f[0]); C = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_G2_G1_entry& modify(const int32_t c0, const int32_t c1) { B = c0; C = c1;  return *this; }
    FORCE_INLINE V_G2_G1_entry& modify1(const int32_t c1) { C = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_G2_G1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const V_G2_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_G2_G1_entry& x, const V_G2_G1_entry& y) {
      return x.B == y.B && x.C == y.C;
    }
  };
  
  struct V_G2_G1_mapkey1_idxfn {
    FORCE_INLINE static size_t hash(const V_G2_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_G2_G1_entry& x, const V_G2_G1_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<V_G2_G1_entry, int64_t, 
    PrimaryHashIndex<V_G2_G1_entry, V_G2_G1_mapkey01_idxfn>,
    SecondaryHashIndex<V_G2_G1_entry, V_G2_G1_mapkey1_idxfn>
  > V_G2_G1_map;
  
  
  struct TMP_SUM1_entry {
    int32_t B; RingFactorizedRelation<1, int32_t> __av; TMP_SUM1_entry* nxt; TMP_SUM1_entry* prv;
  
    explicit TMP_SUM1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM1_entry(const int32_t c0, const RingFactorizedRelation<1, int32_t>& c1) { B = c0; __av = c1;  }
    TMP_SUM1_entry(const TMP_SUM1_entry& other) : B(other.B), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM1_entry(const std::vector<std::string>& f, const RingFactorizedRelation<1, int32_t>& v) {
        /* if (f.size() < 1) return; */
        B = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM1_entry& modify(const int32_t c0) { B = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM1_entry& x, const TMP_SUM1_entry& y) {
      return x.B == y.B;
    }
  };
  
  typedef MultiHashMap<TMP_SUM1_entry, RingFactorizedRelation<1, int32_t>, 
    PrimaryHashIndex<TMP_SUM1_entry, TMP_SUM1_mapkey0_idxfn>
  > TMP_SUM1_map;
  
  
  struct TMP_SUM2_entry {
    int32_t B; RingFactorizedRelation<2, int32_t> __av; TMP_SUM2_entry* nxt; TMP_SUM2_entry* prv;
  
    explicit TMP_SUM2_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM2_entry(const int32_t c0, const RingFactorizedRelation<2, int32_t>& c1) { B = c0; __av = c1;  }
    TMP_SUM2_entry(const TMP_SUM2_entry& other) : B(other.B), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM2_entry(const std::vector<std::string>& f, const RingFactorizedRelation<2, int32_t>& v) {
        /* if (f.size() < 1) return; */
        B = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM2_entry& modify(const int32_t c0) { B = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM2_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM2_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM2_entry& x, const TMP_SUM2_entry& y) {
      return x.B == y.B;
    }
  };
  
  typedef MultiHashMap<TMP_SUM2_entry, RingFactorizedRelation<2, int32_t>, 
    PrimaryHashIndex<TMP_SUM2_entry, TMP_SUM2_mapkey0_idxfn>
  > TMP_SUM2_map;
  
  
  struct TMP_SUM3_entry {
    int32_t C; RingFactorizedRelation<3, int32_t> __av; TMP_SUM3_entry* nxt; TMP_SUM3_entry* prv;
  
    explicit TMP_SUM3_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM3_entry(const int32_t c0, const RingFactorizedRelation<3, int32_t>& c1) { C = c0; __av = c1;  }
    TMP_SUM3_entry(const TMP_SUM3_entry& other) : C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM3_entry(const std::vector<std::string>& f, const RingFactorizedRelation<3, int32_t>& v) {
        /* if (f.size() < 1) return; */
        C = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM3_entry& modify(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM3_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM3_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM3_entry& x, const TMP_SUM3_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<TMP_SUM3_entry, RingFactorizedRelation<3, int32_t>, 
    PrimaryHashIndex<TMP_SUM3_entry, TMP_SUM3_mapkey0_idxfn>
  > TMP_SUM3_map;
  
  
  struct TMP_SUM4_entry {
    int32_t B; RingFactorizedRelation<2, int32_t> __av; TMP_SUM4_entry* nxt; TMP_SUM4_entry* prv;
  
    explicit TMP_SUM4_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM4_entry(const int32_t c0, const RingFactorizedRelation<2, int32_t>& c1) { B = c0; __av = c1;  }
    TMP_SUM4_entry(const TMP_SUM4_entry& other) : B(other.B), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM4_entry(const std::vector<std::string>& f, const RingFactorizedRelation<2, int32_t>& v) {
        /* if (f.size() < 1) return; */
        B = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM4_entry& modify(const int32_t c0) { B = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM4_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM4_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM4_entry& x, const TMP_SUM4_entry& y) {
      return x.B == y.B;
    }
  };
  
  typedef MultiHashMap<TMP_SUM4_entry, RingFactorizedRelation<2, int32_t>, 
    PrimaryHashIndex<TMP_SUM4_entry, TMP_SUM4_mapkey0_idxfn>
  > TMP_SUM4_map;
  
  
  struct TMP_SUM5_entry {
    int32_t B; RingFactorizedRelation<1, int32_t> __av; TMP_SUM5_entry* nxt; TMP_SUM5_entry* prv;
  
    explicit TMP_SUM5_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM5_entry(const int32_t c0, const RingFactorizedRelation<1, int32_t>& c1) { B = c0; __av = c1;  }
    TMP_SUM5_entry(const TMP_SUM5_entry& other) : B(other.B), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM5_entry(const std::vector<std::string>& f, const RingFactorizedRelation<1, int32_t>& v) {
        /* if (f.size() < 1) return; */
        B = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM5_entry& modify(const int32_t c0) { B = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM5_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM5_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM5_entry& x, const TMP_SUM5_entry& y) {
      return x.B == y.B;
    }
  };
  
  typedef MultiHashMap<TMP_SUM5_entry, RingFactorizedRelation<1, int32_t>, 
    PrimaryHashIndex<TMP_SUM5_entry, TMP_SUM5_mapkey0_idxfn>
  > TMP_SUM5_map;
  
  
  struct TMP_SUM6_entry {
    int32_t C; RingFactorizedRelation<3, int32_t> __av; TMP_SUM6_entry* nxt; TMP_SUM6_entry* prv;
  
    explicit TMP_SUM6_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM6_entry(const int32_t c0, const RingFactorizedRelation<3, int32_t>& c1) { C = c0; __av = c1;  }
    TMP_SUM6_entry(const TMP_SUM6_entry& other) : C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM6_entry(const std::vector<std::string>& f, const RingFactorizedRelation<3, int32_t>& v) {
        /* if (f.size() < 1) return; */
        C = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM6_entry& modify(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM6_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM6_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM6_entry& x, const TMP_SUM6_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<TMP_SUM6_entry, RingFactorizedRelation<3, int32_t>, 
    PrimaryHashIndex<TMP_SUM6_entry, TMP_SUM6_mapkey0_idxfn>
  > TMP_SUM6_map;
  
  
  struct TMP_SUM7_entry {
    int32_t B; RingFactorizedRelation<2, int32_t> __av; TMP_SUM7_entry* nxt; TMP_SUM7_entry* prv;
  
    explicit TMP_SUM7_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM7_entry(const int32_t c0, const RingFactorizedRelation<2, int32_t>& c1) { B = c0; __av = c1;  }
    TMP_SUM7_entry(const TMP_SUM7_entry& other) : B(other.B), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM7_entry(const std::vector<std::string>& f, const RingFactorizedRelation<2, int32_t>& v) {
        /* if (f.size() < 1) return; */
        B = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM7_entry& modify(const int32_t c0) { B = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM7_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM7_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM7_entry& x, const TMP_SUM7_entry& y) {
      return x.B == y.B;
    }
  };
  
  typedef MultiHashMap<TMP_SUM7_entry, RingFactorizedRelation<2, int32_t>, 
    PrimaryHashIndex<TMP_SUM7_entry, TMP_SUM7_mapkey0_idxfn>
  > TMP_SUM7_map;
  
  
  struct DELTA_G1_entry {
    int32_t a; int32_t b; int64_t __av; DELTA_G1_entry* nxt; DELTA_G1_entry* prv;
  
    explicit DELTA_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_G1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { a = c0; b = c1; __av = c2;  }
    DELTA_G1_entry(const DELTA_G1_entry& other) : a(other.a), b(other.b), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        a = std::stoi(f[0]); b = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_G1_entry& modify(const int32_t c0, const int32_t c1) { a = c0; b = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_G1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.a);
      hash_combine(h, e.b);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_G1_entry& x, const DELTA_G1_entry& y) {
      return x.a == y.a && x.b == y.b;
    }
  };
  
  typedef MultiHashMap<DELTA_G1_entry, int64_t, 
    PrimaryHashIndex<DELTA_G1_entry, DELTA_G1_mapkey01_idxfn>
  > DELTA_G1_map;
  
  
  struct DELTA_G2_entry {
    int32_t b; int32_t c; int64_t __av; DELTA_G2_entry* nxt; DELTA_G2_entry* prv;
  
    explicit DELTA_G2_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_G2_entry(const int32_t c0, const int32_t c1, const int64_t c2) { b = c0; c = c1; __av = c2;  }
    DELTA_G2_entry(const DELTA_G2_entry& other) : b(other.b), c(other.c), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_G2_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        b = std::stoi(f[0]); c = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_G2_entry& modify(const int32_t c0, const int32_t c1) { b = c0; c = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_G2_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_G2_entry& e) {
      size_t h = 0;
      hash_combine(h, e.b);
      hash_combine(h, e.c);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_G2_entry& x, const DELTA_G2_entry& y) {
      return x.b == y.b && x.c == y.c;
    }
  };
  
  typedef MultiHashMap<DELTA_G2_entry, int64_t, 
    PrimaryHashIndex<DELTA_G2_entry, DELTA_G2_mapkey01_idxfn>
  > DELTA_G2_map;
  
  
  struct DELTA_G3_entry {
    int32_t c; int32_t d; int64_t __av; DELTA_G3_entry* nxt; DELTA_G3_entry* prv;
  
    explicit DELTA_G3_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_G3_entry(const int32_t c0, const int32_t c1, const int64_t c2) { c = c0; d = c1; __av = c2;  }
    DELTA_G3_entry(const DELTA_G3_entry& other) : c(other.c), d(other.d), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_G3_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        c = std::stoi(f[0]); d = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_G3_entry& modify(const int32_t c0, const int32_t c1) { c = c0; d = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, d);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_G3_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_G3_entry& e) {
      size_t h = 0;
      hash_combine(h, e.c);
      hash_combine(h, e.d);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_G3_entry& x, const DELTA_G3_entry& y) {
      return x.c == y.c && x.d == y.d;
    }
  };
  
  typedef MultiHashMap<DELTA_G3_entry, int64_t, 
    PrimaryHashIndex<DELTA_G3_entry, DELTA_G3_mapkey01_idxfn>
  > DELTA_G3_map;
  
  
  struct DELTA_V1_entry {
    int32_t a; int64_t __av; DELTA_V1_entry* nxt; DELTA_V1_entry* prv;
  
    explicit DELTA_V1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_V1_entry(const int32_t c0, const int64_t c1) { a = c0; __av = c1;  }
    DELTA_V1_entry(const DELTA_V1_entry& other) : a(other.a), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_V1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        a = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_V1_entry& modify(const int32_t c0) { a = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_V1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_V1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.a);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_V1_entry& x, const DELTA_V1_entry& y) {
      return x.a == y.a;
    }
  };
  
  typedef MultiHashMap<DELTA_V1_entry, int64_t, 
    PrimaryHashIndex<DELTA_V1_entry, DELTA_V1_mapkey0_idxfn>
  > DELTA_V1_map;
  
  
  struct DELTA_V2_entry {
    int32_t d; int64_t __av; DELTA_V2_entry* nxt; DELTA_V2_entry* prv;
  
    explicit DELTA_V2_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_V2_entry(const int32_t c0, const int64_t c1) { d = c0; __av = c1;  }
    DELTA_V2_entry(const DELTA_V2_entry& other) : d(other.d), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_V2_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        d = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_V2_entry& modify(const int32_t c0) { d = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, d);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_V2_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_V2_entry& e) {
      size_t h = 0;
      hash_combine(h, e.d);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_V2_entry& x, const DELTA_V2_entry& y) {
      return x.d == y.d;
    }
  };
  
  typedef MultiHashMap<DELTA_V2_entry, int64_t, 
    PrimaryHashIndex<DELTA_V2_entry, DELTA_V2_mapkey0_idxfn>
  > DELTA_V2_map;

  

  /* Defines top-level materialized views */
  struct tlq_t {
    struct timeval t0, t; 
    size_t tT, tN, tS;
  
    tlq_t(): tN(0), tS(0) , V_B_GVGVG1(RingFactorizedRelation<0, int32_t>()) { 
      gettimeofday(&t0, NULL); 
    }
  
    /* Serialization code */
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << "\n";
      const RingFactorizedRelation<0, int32_t>& _V_B_GVGVG1 = get_V_B_GVGVG1();
      dbtoaster::serialize_nvp_tabbed(ar, STRING(V_B_GVGVG1), _V_B_GVGVG1, "\t");
      
      ar << "\n";
      const V_A_GV1_map& _V_A_GV1 = get_V_A_GV1();
      dbtoaster::serialize_nvp_tabbed(ar, STRING(V_A_GV1), _V_A_GV1, "\t");
      
      ar << "\n";
      const V_C_GVG1_map& _V_C_GVG1 = get_V_C_GVG1();
      dbtoaster::serialize_nvp_tabbed(ar, STRING(V_C_GVG1), _V_C_GVG1, "\t");
      
      ar << "\n";
      const V_D_GV1_map& _V_D_GV1 = get_V_D_GV1();
      dbtoaster::serialize_nvp_tabbed(ar, STRING(V_D_GV1), _V_D_GV1, "\t");
    }
  
    /* Functions returning / computing the results of top level queries */
    const RingFactorizedRelation<0, int32_t>& get_V_B_GVGVG1() const {
      return V_B_GVGVG1;
    }
    
    const V_A_GV1_map& get_V_A_GV1() const {
      return V_A_GV1;
    }
    
    const V_C_GVG1_map& get_V_C_GVG1() const {
      return V_C_GVG1;
    }
    
    const V_D_GV1_map& get_V_D_GV1() const {
      return V_D_GV1;
    }
  
  protected:
    /* Data structures used for storing / computing top-level queries */
    RingFactorizedRelation<0, int32_t> V_B_GVGVG1;
    V_A_GV1_map V_A_GV1;
    V_C_GVG1_map V_C_GVG1;
    V_D_GV1_map V_D_GV1;
    
  };

  /* Contains materialized views and processing (IVM) logic */
  struct data_t : tlq_t {
  
    data_t(): tlq_t() {
      
      
    }
  
    
  
    
  
    /* Trigger functions for table relations */
    
    
    /* Trigger functions for stream relations */
    void on_batch_update_G1(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM1.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& a = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& b = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v1 = chunk.payload[i];
          TMP_SUM1.addOrDelOnZero(se1.modify(b), ((v1 * V_V1_V1.getValueOrDefault(se2.modify(a))) * Ulift<1>(a)));
        }
      }
      
      { //foreach
        TMP_SUM1_entry* e2 = TMP_SUM1.head;
        while (e2) {
          int32_t b = e2->B;
          RingFactorizedRelation<1, int32_t>& v2 = e2->__av;
          V_B_GVGVG1 += ((v2 * V_C_GVG1.getValueOrDefault(se4.modify(b))) * Ulift<0>(b));
          e2 = e2->nxt;
        }
      }
      
      { //foreach
        TMP_SUM1_entry* e3 = TMP_SUM1.head;
        while (e3) {
          int32_t b = e3->B;
          RingFactorizedRelation<1, int32_t>& v3 = e3->__av;
          V_A_GV1.addOrDelOnZero(se5.modify(b), v3);
          e3 = e3->nxt;
        }
      }
      
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& a = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& b = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v4 = chunk.payload[i];
          V_G1_G1.addOrDelOnZero(se6.modify(a, b), v4);
        }
      }
    }
    
    
    void on_batch_update_G2(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM2.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& b = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v5 = chunk.payload[i];
          TMP_SUM2.addOrDelOnZero(se7.modify(b), ((v5 * V_D_GV1.getValueOrDefault(se8.modify(c))) * Ulift<2>(c)));
        }
      }
      
      { //foreach
        TMP_SUM2_entry* e6 = TMP_SUM2.head;
        while (e6) {
          int32_t b = e6->B;
          RingFactorizedRelation<2, int32_t>& v6 = e6->__av;
          V_B_GVGVG1 += ((v6 * V_A_GV1.getValueOrDefault(se10.modify(b))) * Ulift<0>(b));
          e6 = e6->nxt;
        }
      }
      
      { //foreach
        TMP_SUM2_entry* e7 = TMP_SUM2.head;
        while (e7) {
          int32_t b = e7->B;
          RingFactorizedRelation<2, int32_t>& v7 = e7->__av;
          V_C_GVG1.addOrDelOnZero(se11.modify(b), v7);
          e7 = e7->nxt;
        }
      }
      
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& b = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v8 = chunk.payload[i];
          V_G2_G1.addOrDelOnZero(se12.modify(b, c), v8);
        }
      }
    }
    
    
    void on_batch_update_G3(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM3.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& d = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v9 = chunk.payload[i];
          TMP_SUM3.addOrDelOnZero(se13.modify(c), ((v9 * V_V2_V1.getValueOrDefault(se14.modify(d))) * Ulift<3>(d)));
        }
      }
      
      TMP_SUM4.clear();
      { //foreach
        TMP_SUM3_entry* e10 = TMP_SUM3.head;
        while (e10) {
          int32_t c = e10->C;
          RingFactorizedRelation<3, int32_t>& v10 = e10->__av;
          { //slice
            const LinkedNode<V_G2_G1_entry>* n1 = static_cast<const LinkedNode<V_G2_G1_entry>*>(V_G2_G1.slice(se16.modify1(c), 0));
            V_G2_G1_entry* e11;
            while (n1) {
              e11 = n1->obj;
              int32_t b = e11->B;
              int64_t v11 = e11->__av;
              TMP_SUM4.addOrDelOnZero(se15.modify(b), ((v10 * v11) * Ulift<2>(c)));
              n1 = n1->next;
            }
          }
          e10 = e10->nxt;
        }
      }
      
      { //foreach
        TMP_SUM4_entry* e12 = TMP_SUM4.head;
        while (e12) {
          int32_t b = e12->B;
          RingFactorizedRelation<2, int32_t>& v12 = e12->__av;
          V_B_GVGVG1 += ((v12 * V_A_GV1.getValueOrDefault(se18.modify(b))) * Ulift<0>(b));
          e12 = e12->nxt;
        }
      }
      
      { //foreach
        TMP_SUM4_entry* e13 = TMP_SUM4.head;
        while (e13) {
          int32_t b = e13->B;
          RingFactorizedRelation<2, int32_t>& v13 = e13->__av;
          V_C_GVG1.addOrDelOnZero(se19.modify(b), v13);
          e13 = e13->nxt;
        }
      }
      
      { //foreach
        TMP_SUM3_entry* e14 = TMP_SUM3.head;
        while (e14) {
          int32_t c = e14->C;
          RingFactorizedRelation<3, int32_t>& v14 = e14->__av;
          V_D_GV1.addOrDelOnZero(se20.modify(c), v14);
          e14 = e14->nxt;
        }
      }
      
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& d = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v15 = chunk.payload[i];
          V_G3_G1.addOrDelOnZero(se21.modify(c, d), v15);
        }
      }
    }
    
    
    void on_batch_update_V1(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM5.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& a = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& v16 = chunk.payload[i];
          { //slice
            const LinkedNode<V_G1_G1_entry>* n2 = static_cast<const LinkedNode<V_G1_G1_entry>*>(V_G1_G1.slice(se23.modify0(a), 0));
            V_G1_G1_entry* e17;
            while (n2) {
              e17 = n2->obj;
              int32_t b = e17->B;
              int64_t v17 = e17->__av;
              TMP_SUM5.addOrDelOnZero(se22.modify(b), ((v16 * v17) * Ulift<1>(a)));
              n2 = n2->next;
            }
          }
        }
      }
      
      { //foreach
        TMP_SUM5_entry* e18 = TMP_SUM5.head;
        while (e18) {
          int32_t b = e18->B;
          RingFactorizedRelation<1, int32_t>& v18 = e18->__av;
          V_B_GVGVG1 += ((v18 * V_C_GVG1.getValueOrDefault(se25.modify(b))) * Ulift<0>(b));
          e18 = e18->nxt;
        }
      }
      
      { //foreach
        TMP_SUM5_entry* e19 = TMP_SUM5.head;
        while (e19) {
          int32_t b = e19->B;
          RingFactorizedRelation<1, int32_t>& v19 = e19->__av;
          V_A_GV1.addOrDelOnZero(se26.modify(b), v19);
          e19 = e19->nxt;
        }
      }
      
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& a = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& v20 = chunk.payload[i];
          V_V1_V1.addOrDelOnZero(se27.modify(a), v20);
        }
      }
    }
    
    
    void on_batch_update_V2(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM6.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& d = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& v21 = chunk.payload[i];
          { //slice
            const LinkedNode<V_G3_G1_entry>* n3 = static_cast<const LinkedNode<V_G3_G1_entry>*>(V_G3_G1.slice(se29.modify1(d), 0));
            V_G3_G1_entry* e22;
            while (n3) {
              e22 = n3->obj;
              int32_t c = e22->C;
              int64_t v22 = e22->__av;
              TMP_SUM6.addOrDelOnZero(se28.modify(c), ((v21 * v22) * Ulift<3>(d)));
              n3 = n3->next;
            }
          }
        }
      }
      
      TMP_SUM7.clear();
      { //foreach
        TMP_SUM6_entry* e23 = TMP_SUM6.head;
        while (e23) {
          int32_t c = e23->C;
          RingFactorizedRelation<3, int32_t>& v23 = e23->__av;
          { //slice
            const LinkedNode<V_G2_G1_entry>* n4 = static_cast<const LinkedNode<V_G2_G1_entry>*>(V_G2_G1.slice(se31.modify1(c), 0));
            V_G2_G1_entry* e24;
            while (n4) {
              e24 = n4->obj;
              int32_t b = e24->B;
              int64_t v24 = e24->__av;
              TMP_SUM7.addOrDelOnZero(se30.modify(b), ((v23 * v24) * Ulift<2>(c)));
              n4 = n4->next;
            }
          }
          e23 = e23->nxt;
        }
      }
      
      { //foreach
        TMP_SUM7_entry* e25 = TMP_SUM7.head;
        while (e25) {
          int32_t b = e25->B;
          RingFactorizedRelation<2, int32_t>& v25 = e25->__av;
          V_B_GVGVG1 += ((v25 * V_A_GV1.getValueOrDefault(se33.modify(b))) * Ulift<0>(b));
          e25 = e25->nxt;
        }
      }
      
      { //foreach
        TMP_SUM7_entry* e26 = TMP_SUM7.head;
        while (e26) {
          int32_t b = e26->B;
          RingFactorizedRelation<2, int32_t>& v26 = e26->__av;
          V_C_GVG1.addOrDelOnZero(se34.modify(b), v26);
          e26 = e26->nxt;
        }
      }
      
      { //foreach
        TMP_SUM6_entry* e27 = TMP_SUM6.head;
        while (e27) {
          int32_t c = e27->C;
          RingFactorizedRelation<3, int32_t>& v27 = e27->__av;
          V_D_GV1.addOrDelOnZero(se35.modify(c), v27);
          e27 = e27->nxt;
        }
      }
      
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& d = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& v28 = chunk.payload[i];
          V_V2_V1.addOrDelOnZero(se36.modify(d), v28);
        }
      }
    }
    
    
    void on_system_ready_event() {
      
    }
  
  private:
    
      /* Preallocated map entries (to avoid recreation of temporary objects) */
      TMP_SUM1_entry se1;
      V_V1_V1_entry se2;
      V_C_GVG1_entry se4;
      V_A_GV1_entry se5;
      V_G1_G1_entry se6;
      TMP_SUM2_entry se7;
      V_D_GV1_entry se8;
      V_A_GV1_entry se10;
      V_C_GVG1_entry se11;
      V_G2_G1_entry se12;
      TMP_SUM3_entry se13;
      V_V2_V1_entry se14;
      TMP_SUM4_entry se15;
      V_G2_G1_entry se16;
      V_A_GV1_entry se18;
      V_C_GVG1_entry se19;
      V_D_GV1_entry se20;
      V_G3_G1_entry se21;
      TMP_SUM5_entry se22;
      V_G1_G1_entry se23;
      V_C_GVG1_entry se25;
      V_A_GV1_entry se26;
      V_V1_V1_entry se27;
      TMP_SUM6_entry se28;
      V_G3_G1_entry se29;
      TMP_SUM7_entry se30;
      V_G2_G1_entry se31;
      V_A_GV1_entry se33;
      V_C_GVG1_entry se34;
      V_D_GV1_entry se35;
      V_V2_V1_entry se36;
    
      
    
      /* Data structures used for storing materialized views */
      V_G1_G1_map V_G1_G1;
      V_V1_V1_map V_V1_V1;
      V_G3_G1_map V_G3_G1;
      V_V2_V1_map V_V2_V1;
      V_G2_G1_map V_G2_G1;
      TMP_SUM1_map TMP_SUM1;
      TMP_SUM2_map TMP_SUM2;
      TMP_SUM3_map TMP_SUM3;
      TMP_SUM4_map TMP_SUM4;
      TMP_SUM5_map TMP_SUM5;
      TMP_SUM6_map TMP_SUM6;
      TMP_SUM7_map TMP_SUM7;
      DELTA_G1_map DELTA_G1;
      DELTA_G2_map DELTA_G2;
      DELTA_G3_map DELTA_G3;
      DELTA_V1_map DELTA_V1;
      DELTA_V2_map DELTA_V2;
    
      
    
  };

  

  namespace Config {
    static const std::vector<DataSourceConfig> DataSources = {
    {
      "G1",
      true,
      DataSourceType::CSV,
      "unused.g1",
      // schema
      {{"a", PrimitiveType::INT32}, {"b", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_G1(chunk);
      }
    },
    {
      "G2",
      true,
      DataSourceType::CSV,
      "unused.g2",
      // schema
      {{"b", PrimitiveType::INT32}, {"c", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_G2(chunk);
      }
    },
    {
      "G3",
      true,
      DataSourceType::CSV,
      "unused.g3",
      // schema
      {{"c", PrimitiveType::INT32}, {"d", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_G3(chunk);
      }
    },
    {
      "V1",
      true,
      DataSourceType::CSV,
      "unused.v1",
      // schema
      {{"a", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_V1(chunk);
      }
    },
    {
      "V2",
      true,
      DataSourceType::CSV,
      "unused.v2",
      // schema
      {{"d", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_V2(chunk);
      }
    }
    };
  }

}