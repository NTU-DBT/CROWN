#include <sys/time.h>
#include <vector>
#include "dbtoaster/functions.hpp"
#include "dbtoaster/hash.hpp"
#include "dbtoaster/macro.hpp"
#include "dbtoaster/mmap.hpp"
#include "dbtoaster/serialization.hpp"
#include "dbtoaster/types.hpp"
#include "common.hpp"

#include "ring/ring_factorized.hpp"

#define RELATION_G1_DYNAMIC
#define RELATION_G2_DYNAMIC
#define RELATION_G3_DYNAMIC

namespace dbtoaster {

  /* Definitions of maps used for storing materialized views. */
  struct G1_entry {
    int32_t a; int32_t b; int64_t __av; G1_entry* nxt; G1_entry* prv;
  
    explicit G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit G1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { a = c0; b = c1; __av = c2;  }
    G1_entry(const G1_entry& other) : a(other.a), b(other.b), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        a = std::stoi(f[0]); b = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct G2_entry {
    int32_t b; int32_t c; int64_t __av; G2_entry* nxt; G2_entry* prv;
  
    explicit G2_entry() : nxt(nullptr), prv(nullptr) { }
    explicit G2_entry(const int32_t c0, const int32_t c1, const int64_t c2) { b = c0; c = c1; __av = c2;  }
    G2_entry(const G2_entry& other) : b(other.b), c(other.c), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    G2_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        b = std::stoi(f[0]); c = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct G3_entry {
    int32_t c; int32_t d; int64_t __av; G3_entry* nxt; G3_entry* prv;
  
    explicit G3_entry() : nxt(nullptr), prv(nullptr) { }
    explicit G3_entry(const int32_t c0, const int32_t c1, const int64_t c2) { c = c0; d = c1; __av = c2;  }
    G3_entry(const G3_entry& other) : c(other.c), d(other.d), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    G3_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        c = std::stoi(f[0]); d = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, d);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  struct V_C_GG1_entry {
    int32_t B; RingFactorizedRelation<1, int32_t> __av; V_C_GG1_entry* nxt; V_C_GG1_entry* prv;
  
    explicit V_C_GG1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_C_GG1_entry(const int32_t c0, const RingFactorizedRelation<1, int32_t>& c1) { B = c0; __av = c1;  }
    V_C_GG1_entry(const V_C_GG1_entry& other) : B(other.B), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_C_GG1_entry(const std::vector<std::string>& f, const RingFactorizedRelation<1, int32_t>& v) {
        /* if (f.size() < 1) return; */
        B = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_C_GG1_entry& modify(const int32_t c0) { B = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_C_GG1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_C_GG1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_C_GG1_entry& x, const V_C_GG1_entry& y) {
      return x.B == y.B;
    }
  };
  
  typedef MultiHashMap<V_C_GG1_entry, RingFactorizedRelation<1, int32_t>, 
    PrimaryHashIndex<V_C_GG1_entry, V_C_GG1_mapkey0_idxfn>
  > V_C_GG1_map;
  
  
  struct V_D_G1_entry {
    int32_t C; int64_t __av; V_D_G1_entry* nxt; V_D_G1_entry* prv;
  
    explicit V_D_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_D_G1_entry(const int32_t c0, const int64_t c1) { C = c0; __av = c1;  }
    V_D_G1_entry(const V_D_G1_entry& other) : C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_D_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        C = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_D_G1_entry& modify(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_D_G1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_D_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_D_G1_entry& x, const V_D_G1_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<V_D_G1_entry, int64_t, 
    PrimaryHashIndex<V_D_G1_entry, V_D_G1_mapkey0_idxfn>
  > V_D_G1_map;
  
  
  struct V_G2_G1_entry {
    int32_t B; int32_t C; int64_t __av; V_G2_G1_entry* nxt; V_G2_G1_entry* prv;
  
    explicit V_G2_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_G2_G1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { B = c0; C = c1; __av = c2;  }
    V_G2_G1_entry(const V_G2_G1_entry& other) : B(other.B), C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_G2_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        B = std::stoi(f[0]); C = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_G2_G1_entry& modify(const int32_t c0, const int32_t c1) { B = c0; C = c1;  return *this; }
    FORCE_INLINE V_G2_G1_entry& modify1(const int32_t c1) { C = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_G2_G1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const V_G2_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_G2_G1_entry& x, const V_G2_G1_entry& y) {
      return x.B == y.B && x.C == y.C;
    }
  };
  
  struct V_G2_G1_mapkey1_idxfn {
    FORCE_INLINE static size_t hash(const V_G2_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_G2_G1_entry& x, const V_G2_G1_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<V_G2_G1_entry, int64_t, 
    PrimaryHashIndex<V_G2_G1_entry, V_G2_G1_mapkey01_idxfn>,
    SecondaryHashIndex<V_G2_G1_entry, V_G2_G1_mapkey1_idxfn>
  > V_G2_G1_map;
  
  
  struct V_A_G1_entry {
    int32_t B; int64_t __av; V_A_G1_entry* nxt; V_A_G1_entry* prv;
  
    explicit V_A_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_A_G1_entry(const int32_t c0, const int64_t c1) { B = c0; __av = c1;  }
    V_A_G1_entry(const V_A_G1_entry& other) : B(other.B), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_A_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        B = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_A_G1_entry& modify(const int32_t c0) { B = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_A_G1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_A_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_A_G1_entry& x, const V_A_G1_entry& y) {
      return x.B == y.B;
    }
  };
  
  typedef MultiHashMap<V_A_G1_entry, int64_t, 
    PrimaryHashIndex<V_A_G1_entry, V_A_G1_mapkey0_idxfn>
  > V_A_G1_map;
  
  
  struct TMP_SUM1_entry {
    int32_t B; int64_t __av; TMP_SUM1_entry* nxt; TMP_SUM1_entry* prv;
  
    explicit TMP_SUM1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM1_entry(const int32_t c0, const int64_t c1) { B = c0; __av = c1;  }
    TMP_SUM1_entry(const TMP_SUM1_entry& other) : B(other.B), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        B = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM1_entry& modify(const int32_t c0) { B = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM1_entry& x, const TMP_SUM1_entry& y) {
      return x.B == y.B;
    }
  };
  
  typedef MultiHashMap<TMP_SUM1_entry, int64_t, 
    PrimaryHashIndex<TMP_SUM1_entry, TMP_SUM1_mapkey0_idxfn>
  > TMP_SUM1_map;
  
  
  struct TMP_SUM2_entry {
    int32_t B; RingFactorizedRelation<1, int32_t> __av; TMP_SUM2_entry* nxt; TMP_SUM2_entry* prv;
  
    explicit TMP_SUM2_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM2_entry(const int32_t c0, const RingFactorizedRelation<1, int32_t>& c1) { B = c0; __av = c1;  }
    TMP_SUM2_entry(const TMP_SUM2_entry& other) : B(other.B), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM2_entry(const std::vector<std::string>& f, const RingFactorizedRelation<1, int32_t>& v) {
        /* if (f.size() < 1) return; */
        B = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM2_entry& modify(const int32_t c0) { B = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM2_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM2_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM2_entry& x, const TMP_SUM2_entry& y) {
      return x.B == y.B;
    }
  };
  
  typedef MultiHashMap<TMP_SUM2_entry, RingFactorizedRelation<1, int32_t>, 
    PrimaryHashIndex<TMP_SUM2_entry, TMP_SUM2_mapkey0_idxfn>
  > TMP_SUM2_map;
  
  
  struct TMP_SUM3_entry {
    int32_t C; int64_t __av; TMP_SUM3_entry* nxt; TMP_SUM3_entry* prv;
  
    explicit TMP_SUM3_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM3_entry(const int32_t c0, const int64_t c1) { C = c0; __av = c1;  }
    TMP_SUM3_entry(const TMP_SUM3_entry& other) : C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM3_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        C = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM3_entry& modify(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM3_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM3_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM3_entry& x, const TMP_SUM3_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<TMP_SUM3_entry, int64_t, 
    PrimaryHashIndex<TMP_SUM3_entry, TMP_SUM3_mapkey0_idxfn>
  > TMP_SUM3_map;
  
  
  struct TMP_SUM4_entry {
    int32_t B; RingFactorizedRelation<1, int32_t> __av; TMP_SUM4_entry* nxt; TMP_SUM4_entry* prv;
  
    explicit TMP_SUM4_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM4_entry(const int32_t c0, const RingFactorizedRelation<1, int32_t>& c1) { B = c0; __av = c1;  }
    TMP_SUM4_entry(const TMP_SUM4_entry& other) : B(other.B), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM4_entry(const std::vector<std::string>& f, const RingFactorizedRelation<1, int32_t>& v) {
        /* if (f.size() < 1) return; */
        B = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM4_entry& modify(const int32_t c0) { B = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM4_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM4_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM4_entry& x, const TMP_SUM4_entry& y) {
      return x.B == y.B;
    }
  };
  
  typedef MultiHashMap<TMP_SUM4_entry, RingFactorizedRelation<1, int32_t>, 
    PrimaryHashIndex<TMP_SUM4_entry, TMP_SUM4_mapkey0_idxfn>
  > TMP_SUM4_map;
  
  
  struct DELTA_G1_entry {
    int32_t a; int32_t b; int64_t __av; DELTA_G1_entry* nxt; DELTA_G1_entry* prv;
  
    explicit DELTA_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_G1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { a = c0; b = c1; __av = c2;  }
    DELTA_G1_entry(const DELTA_G1_entry& other) : a(other.a), b(other.b), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        a = std::stoi(f[0]); b = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_G1_entry& modify(const int32_t c0, const int32_t c1) { a = c0; b = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_G1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.a);
      hash_combine(h, e.b);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_G1_entry& x, const DELTA_G1_entry& y) {
      return x.a == y.a && x.b == y.b;
    }
  };
  
  typedef MultiHashMap<DELTA_G1_entry, int64_t, 
    PrimaryHashIndex<DELTA_G1_entry, DELTA_G1_mapkey01_idxfn>
  > DELTA_G1_map;
  
  
  struct DELTA_G2_entry {
    int32_t b; int32_t c; int64_t __av; DELTA_G2_entry* nxt; DELTA_G2_entry* prv;
  
    explicit DELTA_G2_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_G2_entry(const int32_t c0, const int32_t c1, const int64_t c2) { b = c0; c = c1; __av = c2;  }
    DELTA_G2_entry(const DELTA_G2_entry& other) : b(other.b), c(other.c), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_G2_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        b = std::stoi(f[0]); c = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_G2_entry& modify(const int32_t c0, const int32_t c1) { b = c0; c = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_G2_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_G2_entry& e) {
      size_t h = 0;
      hash_combine(h, e.b);
      hash_combine(h, e.c);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_G2_entry& x, const DELTA_G2_entry& y) {
      return x.b == y.b && x.c == y.c;
    }
  };
  
  typedef MultiHashMap<DELTA_G2_entry, int64_t, 
    PrimaryHashIndex<DELTA_G2_entry, DELTA_G2_mapkey01_idxfn>
  > DELTA_G2_map;
  
  
  struct DELTA_G3_entry {
    int32_t c; int32_t d; int64_t __av; DELTA_G3_entry* nxt; DELTA_G3_entry* prv;
  
    explicit DELTA_G3_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_G3_entry(const int32_t c0, const int32_t c1, const int64_t c2) { c = c0; d = c1; __av = c2;  }
    DELTA_G3_entry(const DELTA_G3_entry& other) : c(other.c), d(other.d), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_G3_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        c = std::stoi(f[0]); d = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_G3_entry& modify(const int32_t c0, const int32_t c1) { c = c0; d = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, d);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_G3_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_G3_entry& e) {
      size_t h = 0;
      hash_combine(h, e.c);
      hash_combine(h, e.d);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_G3_entry& x, const DELTA_G3_entry& y) {
      return x.c == y.c && x.d == y.d;
    }
  };
  
  typedef MultiHashMap<DELTA_G3_entry, int64_t, 
    PrimaryHashIndex<DELTA_G3_entry, DELTA_G3_mapkey01_idxfn>
  > DELTA_G3_map;

  

  /* Defines top-level materialized views */
  struct tlq_t {
    struct timeval t0, t; 
    size_t tT, tN, tS;
  
    tlq_t(): tN(0), tS(0) , V_B_GGG1(RingFactorizedRelation<0, int32_t>()) { 
      gettimeofday(&t0, NULL); 
    }
  
    /* Serialization code */
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << "\n";
      const RingFactorizedRelation<0, int32_t>& _V_B_GGG1 = get_V_B_GGG1();
      dbtoaster::serialize_nvp_tabbed(ar, STRING(V_B_GGG1), _V_B_GGG1, "\t");
      
      ar << "\n";
      const V_C_GG1_map& _V_C_GG1 = get_V_C_GG1();
      dbtoaster::serialize_nvp_tabbed(ar, STRING(V_C_GG1), _V_C_GG1, "\t");
    }
  
    /* Functions returning / computing the results of top level queries */
    const RingFactorizedRelation<0, int32_t>& get_V_B_GGG1() const {
      return V_B_GGG1;
    }
    
    const V_C_GG1_map& get_V_C_GG1() const {
      return V_C_GG1;
    }
  
  protected:
    /* Data structures used for storing / computing top-level queries */
    RingFactorizedRelation<0, int32_t> V_B_GGG1;
    V_C_GG1_map V_C_GG1;
    
  };

  /* Contains materialized views and processing (IVM) logic */
  struct data_t : tlq_t {
  
    data_t(): tlq_t() {
      
      
    }
  
    
  
    
  
    /* Trigger functions for table relations */
    
    
    /* Trigger functions for stream relations */
    void on_batch_update_G1(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM1.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& a = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& b = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v1 = chunk.payload[i];
          TMP_SUM1.addOrDelOnZero(se1.modify(b), v1);
        }
      }
      
      { //foreach
        TMP_SUM1_entry* e2 = TMP_SUM1.head;
        while (e2) {
          int32_t b = e2->B;
          int64_t v2 = e2->__av;
          V_B_GGG1 += ((v2 * V_C_GG1.getValueOrDefault(se3.modify(b))) * Ulift<0>(b));
          e2 = e2->nxt;
        }
      }
      
      { //foreach
        TMP_SUM1_entry* e3 = TMP_SUM1.head;
        while (e3) {
          int32_t b = e3->B;
          int64_t v3 = e3->__av;
          V_A_G1.addOrDelOnZero(se4.modify(b), v3);
          e3 = e3->nxt;
        }
      }
    }
    
    
    void on_batch_update_G2(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM2.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& b = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v4 = chunk.payload[i];
          TMP_SUM2.addOrDelOnZero(se5.modify(b), ((v4 * V_D_G1.getValueOrDefault(se6.modify(c))) * Ulift<1>(c)));
        }
      }
      
      { //foreach
        TMP_SUM2_entry* e5 = TMP_SUM2.head;
        while (e5) {
          int32_t b = e5->B;
          RingFactorizedRelation<1, int32_t>& v5 = e5->__av;
          V_B_GGG1 += ((v5 * V_A_G1.getValueOrDefault(se8.modify(b))) * Ulift<0>(b));
          e5 = e5->nxt;
        }
      }
      
      { //foreach
        TMP_SUM2_entry* e6 = TMP_SUM2.head;
        while (e6) {
          int32_t b = e6->B;
          RingFactorizedRelation<1, int32_t>& v6 = e6->__av;
          V_C_GG1.addOrDelOnZero(se9.modify(b), v6);
          e6 = e6->nxt;
        }
      }
      
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& b = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v7 = chunk.payload[i];
          V_G2_G1.addOrDelOnZero(se10.modify(b, c), v7);
        }
      }
    }
    
    
    void on_batch_update_G3(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM3.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& d = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v8 = chunk.payload[i];
          TMP_SUM3.addOrDelOnZero(se11.modify(c), v8);
        }
      }
      
      TMP_SUM4.clear();
      { //foreach
        TMP_SUM3_entry* e9 = TMP_SUM3.head;
        while (e9) {
          int32_t c = e9->C;
          int64_t v9 = e9->__av;
          { //slice
            const LinkedNode<V_G2_G1_entry>* n1 = static_cast<const LinkedNode<V_G2_G1_entry>*>(V_G2_G1.slice(se13.modify1(c), 0));
            V_G2_G1_entry* e10;
            while (n1) {
              e10 = n1->obj;
              int32_t b = e10->B;
              int64_t v10 = e10->__av;
              TMP_SUM4.addOrDelOnZero(se12.modify(b), ((v9 * v10) * Ulift<1>(c)));
              n1 = n1->next;
            }
          }
          e9 = e9->nxt;
        }
      }
      
      { //foreach
        TMP_SUM4_entry* e11 = TMP_SUM4.head;
        while (e11) {
          int32_t b = e11->B;
          RingFactorizedRelation<1, int32_t>& v11 = e11->__av;
          V_B_GGG1 += ((v11 * V_A_G1.getValueOrDefault(se15.modify(b))) * Ulift<0>(b));
          e11 = e11->nxt;
        }
      }
      
      { //foreach
        TMP_SUM4_entry* e12 = TMP_SUM4.head;
        while (e12) {
          int32_t b = e12->B;
          RingFactorizedRelation<1, int32_t>& v12 = e12->__av;
          V_C_GG1.addOrDelOnZero(se16.modify(b), v12);
          e12 = e12->nxt;
        }
      }
      
      { //foreach
        TMP_SUM3_entry* e13 = TMP_SUM3.head;
        while (e13) {
          int32_t c = e13->C;
          int64_t v13 = e13->__av;
          V_D_G1.addOrDelOnZero(se17.modify(c), v13);
          e13 = e13->nxt;
        }
      }
    }
    
    
    void on_system_ready_event() {
      
    }
  
  private:
    
      /* Preallocated map entries (to avoid recreation of temporary objects) */
      TMP_SUM1_entry se1;
      V_C_GG1_entry se3;
      V_A_G1_entry se4;
      TMP_SUM2_entry se5;
      V_D_G1_entry se6;
      V_A_G1_entry se8;
      V_C_GG1_entry se9;
      V_G2_G1_entry se10;
      TMP_SUM3_entry se11;
      TMP_SUM4_entry se12;
      V_G2_G1_entry se13;
      V_A_G1_entry se15;
      V_C_GG1_entry se16;
      V_D_G1_entry se17;
    
      
    
      /* Data structures used for storing materialized views */
      V_D_G1_map V_D_G1;
      V_G2_G1_map V_G2_G1;
      V_A_G1_map V_A_G1;
      TMP_SUM1_map TMP_SUM1;
      TMP_SUM2_map TMP_SUM2;
      TMP_SUM3_map TMP_SUM3;
      TMP_SUM4_map TMP_SUM4;
      DELTA_G1_map DELTA_G1;
      DELTA_G2_map DELTA_G2;
      DELTA_G3_map DELTA_G3;
    
      
    
  };

  

  namespace Config {
    static const std::vector<DataSourceConfig> DataSources = {
    {
      "G1",
      true,
      DataSourceType::CSV,
      "unused.g1",
      // schema
      {{"a", PrimitiveType::INT32}, {"b", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_G1(chunk);
      }
    },
    {
      "G2",
      true,
      DataSourceType::CSV,
      "unused.g2",
      // schema
      {{"b", PrimitiveType::INT32}, {"c", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_G2(chunk);
      }
    },
    {
      "G3",
      true,
      DataSourceType::CSV,
      "unused.g3",
      // schema
      {{"c", PrimitiveType::INT32}, {"d", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_G3(chunk);
      }
    }
    };
  }

}