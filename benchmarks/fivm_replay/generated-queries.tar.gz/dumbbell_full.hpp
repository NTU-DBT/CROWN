#include <sys/time.h>
#include <vector>
#include "dbtoaster/functions.hpp"
#include "dbtoaster/hash.hpp"
#include "dbtoaster/macro.hpp"
#include "dbtoaster/mmap.hpp"
#include "dbtoaster/serialization.hpp"
#include "dbtoaster/types.hpp"
#include "common.hpp"

#include "ring/ring_factorized.hpp"

#define RELATION_M_DYNAMIC
#define RELATION_LBC_DYNAMIC
#define RELATION_LCA_DYNAMIC
#define RELATION_RDE_DYNAMIC
#define RELATION_RFD_DYNAMIC
#define RELATION_LAB_DYNAMIC
#define RELATION_REF_DYNAMIC

namespace dbtoaster {

  /* Definitions of maps used for storing materialized views. */
  struct M_entry {
    int32_t c; int32_t d; int64_t __av; M_entry* nxt; M_entry* prv;
  
    explicit M_entry() : nxt(nullptr), prv(nullptr) { }
    explicit M_entry(const int32_t c0, const int32_t c1, const int64_t c2) { c = c0; d = c1; __av = c2;  }
    M_entry(const M_entry& other) : c(other.c), d(other.d), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    M_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        c = std::stoi(f[0]); d = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, d);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct LBC_entry {
    int32_t b; int32_t c; int64_t __av; LBC_entry* nxt; LBC_entry* prv;
  
    explicit LBC_entry() : nxt(nullptr), prv(nullptr) { }
    explicit LBC_entry(const int32_t c0, const int32_t c1, const int64_t c2) { b = c0; c = c1; __av = c2;  }
    LBC_entry(const LBC_entry& other) : b(other.b), c(other.c), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    LBC_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        b = std::stoi(f[0]); c = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct LCA_entry {
    int32_t c; int32_t a; int64_t __av; LCA_entry* nxt; LCA_entry* prv;
  
    explicit LCA_entry() : nxt(nullptr), prv(nullptr) { }
    explicit LCA_entry(const int32_t c0, const int32_t c1, const int64_t c2) { c = c0; a = c1; __av = c2;  }
    LCA_entry(const LCA_entry& other) : c(other.c), a(other.a), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    LCA_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        c = std::stoi(f[0]); a = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct RDE_entry {
    int32_t d; int32_t e; int64_t __av; RDE_entry* nxt; RDE_entry* prv;
  
    explicit RDE_entry() : nxt(nullptr), prv(nullptr) { }
    explicit RDE_entry(const int32_t c0, const int32_t c1, const int64_t c2) { d = c0; e = c1; __av = c2;  }
    RDE_entry(const RDE_entry& other) : d(other.d), e(other.e), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    RDE_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        d = std::stoi(f[0]); e = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, d);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, e);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct RFD_entry {
    int32_t ff; int32_t d; int64_t __av; RFD_entry* nxt; RFD_entry* prv;
  
    explicit RFD_entry() : nxt(nullptr), prv(nullptr) { }
    explicit RFD_entry(const int32_t c0, const int32_t c1, const int64_t c2) { ff = c0; d = c1; __av = c2;  }
    RFD_entry(const RFD_entry& other) : ff(other.ff), d(other.d), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    RFD_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        ff = std::stoi(f[0]); d = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, ff);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, d);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct LAB_entry {
    int32_t a; int32_t b; int64_t __av; LAB_entry* nxt; LAB_entry* prv;
  
    explicit LAB_entry() : nxt(nullptr), prv(nullptr) { }
    explicit LAB_entry(const int32_t c0, const int32_t c1, const int64_t c2) { a = c0; b = c1; __av = c2;  }
    LAB_entry(const LAB_entry& other) : a(other.a), b(other.b), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    LAB_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        a = std::stoi(f[0]); b = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct REF_entry {
    int32_t e; int32_t ff; int64_t __av; REF_entry* nxt; REF_entry* prv;
  
    explicit REF_entry() : nxt(nullptr), prv(nullptr) { }
    explicit REF_entry(const int32_t c0, const int32_t c1, const int64_t c2) { e = c0; ff = c1; __av = c2;  }
    REF_entry(const REF_entry& other) : e(other.e), ff(other.ff), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    REF_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        e = std::stoi(f[0]); ff = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, e);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, ff);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  struct V_A_LLL1_entry {
    int32_t C; RingFactorizedRelation<1, int32_t> __av; V_A_LLL1_entry* nxt; V_A_LLL1_entry* prv;
  
    explicit V_A_LLL1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_A_LLL1_entry(const int32_t c0, const RingFactorizedRelation<1, int32_t>& c1) { C = c0; __av = c1;  }
    V_A_LLL1_entry(const V_A_LLL1_entry& other) : C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_A_LLL1_entry(const std::vector<std::string>& f, const RingFactorizedRelation<1, int32_t>& v) {
        /* if (f.size() < 1) return; */
        C = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_A_LLL1_entry& modify(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_A_LLL1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_A_LLL1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_A_LLL1_entry& x, const V_A_LLL1_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<V_A_LLL1_entry, RingFactorizedRelation<1, int32_t>, 
    PrimaryHashIndex<V_A_LLL1_entry, V_A_LLL1_mapkey0_idxfn>
  > V_A_LLL1_map;
  
  
  struct V_B_LL1_entry {
    int32_t C; int32_t A; RingFactorizedRelation<2, int32_t> __av; V_B_LL1_entry* nxt; V_B_LL1_entry* prv;
  
    explicit V_B_LL1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_B_LL1_entry(const int32_t c0, const int32_t c1, const RingFactorizedRelation<2, int32_t>& c2) { C = c0; A = c1; __av = c2;  }
    V_B_LL1_entry(const V_B_LL1_entry& other) : C(other.C), A(other.A), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_B_LL1_entry(const std::vector<std::string>& f, const RingFactorizedRelation<2, int32_t>& v) {
        /* if (f.size() < 2) return; */
        C = std::stoi(f[0]); A = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_B_LL1_entry& modify(const int32_t c0, const int32_t c1) { C = c0; A = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, A);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_B_LL1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const V_B_LL1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      hash_combine(h, e.A);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_B_LL1_entry& x, const V_B_LL1_entry& y) {
      return x.C == y.C && x.A == y.A;
    }
  };
  
  typedef MultiHashMap<V_B_LL1_entry, RingFactorizedRelation<2, int32_t>, 
    PrimaryHashIndex<V_B_LL1_entry, V_B_LL1_mapkey01_idxfn>
  > V_B_LL1_map;
  
  
  struct V_LBC_L1_entry {
    int32_t B; int32_t C; int64_t __av; V_LBC_L1_entry* nxt; V_LBC_L1_entry* prv;
  
    explicit V_LBC_L1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_LBC_L1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { B = c0; C = c1; __av = c2;  }
    V_LBC_L1_entry(const V_LBC_L1_entry& other) : B(other.B), C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_LBC_L1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        B = std::stoi(f[0]); C = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_LBC_L1_entry& modify(const int32_t c0, const int32_t c1) { B = c0; C = c1;  return *this; }
    FORCE_INLINE V_LBC_L1_entry& modify0(const int32_t c0) { B = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_LBC_L1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const V_LBC_L1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_LBC_L1_entry& x, const V_LBC_L1_entry& y) {
      return x.B == y.B && x.C == y.C;
    }
  };
  
  struct V_LBC_L1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_LBC_L1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_LBC_L1_entry& x, const V_LBC_L1_entry& y) {
      return x.B == y.B;
    }
  };
  
  typedef MultiHashMap<V_LBC_L1_entry, int64_t, 
    PrimaryHashIndex<V_LBC_L1_entry, V_LBC_L1_mapkey01_idxfn>,
    SecondaryHashIndex<V_LBC_L1_entry, V_LBC_L1_mapkey0_idxfn>
  > V_LBC_L1_map;
  
  
  struct V_LAB_L1_entry {
    int32_t A; int32_t B; int64_t __av; V_LAB_L1_entry* nxt; V_LAB_L1_entry* prv;
  
    explicit V_LAB_L1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_LAB_L1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { A = c0; B = c1; __av = c2;  }
    V_LAB_L1_entry(const V_LAB_L1_entry& other) : A(other.A), B(other.B), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_LAB_L1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        A = std::stoi(f[0]); B = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_LAB_L1_entry& modify(const int32_t c0, const int32_t c1) { A = c0; B = c1;  return *this; }
    FORCE_INLINE V_LAB_L1_entry& modify1(const int32_t c1) { B = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, A);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_LAB_L1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const V_LAB_L1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.A);
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_LAB_L1_entry& x, const V_LAB_L1_entry& y) {
      return x.A == y.A && x.B == y.B;
    }
  };
  
  struct V_LAB_L1_mapkey1_idxfn {
    FORCE_INLINE static size_t hash(const V_LAB_L1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_LAB_L1_entry& x, const V_LAB_L1_entry& y) {
      return x.B == y.B;
    }
  };
  
  typedef MultiHashMap<V_LAB_L1_entry, int64_t, 
    PrimaryHashIndex<V_LAB_L1_entry, V_LAB_L1_mapkey01_idxfn>,
    SecondaryHashIndex<V_LAB_L1_entry, V_LAB_L1_mapkey1_idxfn>
  > V_LAB_L1_map;
  
  
  struct V_LCA_L1_entry {
    int32_t C; int32_t A; int64_t __av; V_LCA_L1_entry* nxt; V_LCA_L1_entry* prv;
  
    explicit V_LCA_L1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_LCA_L1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { C = c0; A = c1; __av = c2;  }
    V_LCA_L1_entry(const V_LCA_L1_entry& other) : C(other.C), A(other.A), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_LCA_L1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        C = std::stoi(f[0]); A = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_LCA_L1_entry& modify(const int32_t c0, const int32_t c1) { C = c0; A = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, A);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_LCA_L1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const V_LCA_L1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      hash_combine(h, e.A);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_LCA_L1_entry& x, const V_LCA_L1_entry& y) {
      return x.C == y.C && x.A == y.A;
    }
  };
  
  typedef MultiHashMap<V_LCA_L1_entry, int64_t, 
    PrimaryHashIndex<V_LCA_L1_entry, V_LCA_L1_mapkey01_idxfn>
  > V_LCA_L1_map;
  
  
  struct V_D_RRRM1_entry {
    int32_t C; RingFactorizedRelation<3, int32_t> __av; V_D_RRRM1_entry* nxt; V_D_RRRM1_entry* prv;
  
    explicit V_D_RRRM1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_D_RRRM1_entry(const int32_t c0, const RingFactorizedRelation<3, int32_t>& c1) { C = c0; __av = c1;  }
    V_D_RRRM1_entry(const V_D_RRRM1_entry& other) : C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_D_RRRM1_entry(const std::vector<std::string>& f, const RingFactorizedRelation<3, int32_t>& v) {
        /* if (f.size() < 1) return; */
        C = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_D_RRRM1_entry& modify(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_D_RRRM1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_D_RRRM1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_D_RRRM1_entry& x, const V_D_RRRM1_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<V_D_RRRM1_entry, RingFactorizedRelation<3, int32_t>, 
    PrimaryHashIndex<V_D_RRRM1_entry, V_D_RRRM1_mapkey0_idxfn>
  > V_D_RRRM1_map;
  
  
  struct V_E_RRR1_entry {
    int32_t D; RingFactorizedRelation<4, int32_t> __av; V_E_RRR1_entry* nxt; V_E_RRR1_entry* prv;
  
    explicit V_E_RRR1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_E_RRR1_entry(const int32_t c0, const RingFactorizedRelation<4, int32_t>& c1) { D = c0; __av = c1;  }
    V_E_RRR1_entry(const V_E_RRR1_entry& other) : D(other.D), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_E_RRR1_entry(const std::vector<std::string>& f, const RingFactorizedRelation<4, int32_t>& v) {
        /* if (f.size() < 1) return; */
        D = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_E_RRR1_entry& modify(const int32_t c0) { D = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, D);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_E_RRR1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_E_RRR1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.D);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_E_RRR1_entry& x, const V_E_RRR1_entry& y) {
      return x.D == y.D;
    }
  };
  
  typedef MultiHashMap<V_E_RRR1_entry, RingFactorizedRelation<4, int32_t>, 
    PrimaryHashIndex<V_E_RRR1_entry, V_E_RRR1_mapkey0_idxfn>
  > V_E_RRR1_map;
  
  
  struct V_FF_RR1_entry {
    int32_t D; int32_t E; RingFactorizedRelation<5, int32_t> __av; V_FF_RR1_entry* nxt; V_FF_RR1_entry* prv;
  
    explicit V_FF_RR1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_FF_RR1_entry(const int32_t c0, const int32_t c1, const RingFactorizedRelation<5, int32_t>& c2) { D = c0; E = c1; __av = c2;  }
    V_FF_RR1_entry(const V_FF_RR1_entry& other) : D(other.D), E(other.E), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_FF_RR1_entry(const std::vector<std::string>& f, const RingFactorizedRelation<5, int32_t>& v) {
        /* if (f.size() < 2) return; */
        D = std::stoi(f[0]); E = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_FF_RR1_entry& modify(const int32_t c0, const int32_t c1) { D = c0; E = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, D);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, E);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_FF_RR1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const V_FF_RR1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.D);
      hash_combine(h, e.E);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_FF_RR1_entry& x, const V_FF_RR1_entry& y) {
      return x.D == y.D && x.E == y.E;
    }
  };
  
  typedef MultiHashMap<V_FF_RR1_entry, RingFactorizedRelation<5, int32_t>, 
    PrimaryHashIndex<V_FF_RR1_entry, V_FF_RR1_mapkey01_idxfn>
  > V_FF_RR1_map;
  
  
  struct V_RFD_R1_entry {
    int32_t FF; int32_t D; int64_t __av; V_RFD_R1_entry* nxt; V_RFD_R1_entry* prv;
  
    explicit V_RFD_R1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_RFD_R1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { FF = c0; D = c1; __av = c2;  }
    V_RFD_R1_entry(const V_RFD_R1_entry& other) : FF(other.FF), D(other.D), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_RFD_R1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        FF = std::stoi(f[0]); D = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_RFD_R1_entry& modify(const int32_t c0, const int32_t c1) { FF = c0; D = c1;  return *this; }
    FORCE_INLINE V_RFD_R1_entry& modify0(const int32_t c0) { FF = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, FF);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, D);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_RFD_R1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const V_RFD_R1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.FF);
      hash_combine(h, e.D);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_RFD_R1_entry& x, const V_RFD_R1_entry& y) {
      return x.FF == y.FF && x.D == y.D;
    }
  };
  
  struct V_RFD_R1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_RFD_R1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.FF);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_RFD_R1_entry& x, const V_RFD_R1_entry& y) {
      return x.FF == y.FF;
    }
  };
  
  typedef MultiHashMap<V_RFD_R1_entry, int64_t, 
    PrimaryHashIndex<V_RFD_R1_entry, V_RFD_R1_mapkey01_idxfn>,
    SecondaryHashIndex<V_RFD_R1_entry, V_RFD_R1_mapkey0_idxfn>
  > V_RFD_R1_map;
  
  
  struct V_REF_R1_entry {
    int32_t E; int32_t FF; int64_t __av; V_REF_R1_entry* nxt; V_REF_R1_entry* prv;
  
    explicit V_REF_R1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_REF_R1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { E = c0; FF = c1; __av = c2;  }
    V_REF_R1_entry(const V_REF_R1_entry& other) : E(other.E), FF(other.FF), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_REF_R1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        E = std::stoi(f[0]); FF = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_REF_R1_entry& modify(const int32_t c0, const int32_t c1) { E = c0; FF = c1;  return *this; }
    FORCE_INLINE V_REF_R1_entry& modify1(const int32_t c1) { FF = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, E);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, FF);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_REF_R1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const V_REF_R1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.E);
      hash_combine(h, e.FF);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_REF_R1_entry& x, const V_REF_R1_entry& y) {
      return x.E == y.E && x.FF == y.FF;
    }
  };
  
  struct V_REF_R1_mapkey1_idxfn {
    FORCE_INLINE static size_t hash(const V_REF_R1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.FF);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_REF_R1_entry& x, const V_REF_R1_entry& y) {
      return x.FF == y.FF;
    }
  };
  
  typedef MultiHashMap<V_REF_R1_entry, int64_t, 
    PrimaryHashIndex<V_REF_R1_entry, V_REF_R1_mapkey01_idxfn>,
    SecondaryHashIndex<V_REF_R1_entry, V_REF_R1_mapkey1_idxfn>
  > V_REF_R1_map;
  
  
  struct V_RDE_R1_entry {
    int32_t D; int32_t E; int64_t __av; V_RDE_R1_entry* nxt; V_RDE_R1_entry* prv;
  
    explicit V_RDE_R1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_RDE_R1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { D = c0; E = c1; __av = c2;  }
    V_RDE_R1_entry(const V_RDE_R1_entry& other) : D(other.D), E(other.E), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_RDE_R1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        D = std::stoi(f[0]); E = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_RDE_R1_entry& modify(const int32_t c0, const int32_t c1) { D = c0; E = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, D);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, E);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_RDE_R1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const V_RDE_R1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.D);
      hash_combine(h, e.E);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_RDE_R1_entry& x, const V_RDE_R1_entry& y) {
      return x.D == y.D && x.E == y.E;
    }
  };
  
  typedef MultiHashMap<V_RDE_R1_entry, int64_t, 
    PrimaryHashIndex<V_RDE_R1_entry, V_RDE_R1_mapkey01_idxfn>
  > V_RDE_R1_map;
  
  
  struct V_M_M1_entry {
    int32_t C; int32_t D; int64_t __av; V_M_M1_entry* nxt; V_M_M1_entry* prv;
  
    explicit V_M_M1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_M_M1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { C = c0; D = c1; __av = c2;  }
    V_M_M1_entry(const V_M_M1_entry& other) : C(other.C), D(other.D), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_M_M1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        C = std::stoi(f[0]); D = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_M_M1_entry& modify(const int32_t c0, const int32_t c1) { C = c0; D = c1;  return *this; }
    FORCE_INLINE V_M_M1_entry& modify1(const int32_t c1) { D = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, D);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_M_M1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const V_M_M1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      hash_combine(h, e.D);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_M_M1_entry& x, const V_M_M1_entry& y) {
      return x.C == y.C && x.D == y.D;
    }
  };
  
  struct V_M_M1_mapkey1_idxfn {
    FORCE_INLINE static size_t hash(const V_M_M1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.D);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_M_M1_entry& x, const V_M_M1_entry& y) {
      return x.D == y.D;
    }
  };
  
  typedef MultiHashMap<V_M_M1_entry, int64_t, 
    PrimaryHashIndex<V_M_M1_entry, V_M_M1_mapkey01_idxfn>,
    SecondaryHashIndex<V_M_M1_entry, V_M_M1_mapkey1_idxfn>
  > V_M_M1_map;
  
  
  struct TMP_SUM1_entry {
    int32_t C; RingFactorizedRelation<3, int32_t> __av; TMP_SUM1_entry* nxt; TMP_SUM1_entry* prv;
  
    explicit TMP_SUM1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM1_entry(const int32_t c0, const RingFactorizedRelation<3, int32_t>& c1) { C = c0; __av = c1;  }
    TMP_SUM1_entry(const TMP_SUM1_entry& other) : C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM1_entry(const std::vector<std::string>& f, const RingFactorizedRelation<3, int32_t>& v) {
        /* if (f.size() < 1) return; */
        C = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM1_entry& modify(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM1_entry& x, const TMP_SUM1_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<TMP_SUM1_entry, RingFactorizedRelation<3, int32_t>, 
    PrimaryHashIndex<TMP_SUM1_entry, TMP_SUM1_mapkey0_idxfn>
  > TMP_SUM1_map;
  
  
  struct TMP_SUM2_entry {
    int32_t C; int32_t A; RingFactorizedRelation<2, int32_t> __av; TMP_SUM2_entry* nxt; TMP_SUM2_entry* prv;
  
    explicit TMP_SUM2_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM2_entry(const int32_t c0, const int32_t c1, const RingFactorizedRelation<2, int32_t>& c2) { C = c0; A = c1; __av = c2;  }
    TMP_SUM2_entry(const TMP_SUM2_entry& other) : C(other.C), A(other.A), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM2_entry(const std::vector<std::string>& f, const RingFactorizedRelation<2, int32_t>& v) {
        /* if (f.size() < 2) return; */
        C = std::stoi(f[0]); A = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM2_entry& modify(const int32_t c0, const int32_t c1) { C = c0; A = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, A);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM2_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM2_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      hash_combine(h, e.A);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM2_entry& x, const TMP_SUM2_entry& y) {
      return x.C == y.C && x.A == y.A;
    }
  };
  
  typedef MultiHashMap<TMP_SUM2_entry, RingFactorizedRelation<2, int32_t>, 
    PrimaryHashIndex<TMP_SUM2_entry, TMP_SUM2_mapkey01_idxfn>
  > TMP_SUM2_map;
  
  
  struct TMP_SUM3_entry {
    int32_t C; RingFactorizedRelation<1, int32_t> __av; TMP_SUM3_entry* nxt; TMP_SUM3_entry* prv;
  
    explicit TMP_SUM3_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM3_entry(const int32_t c0, const RingFactorizedRelation<1, int32_t>& c1) { C = c0; __av = c1;  }
    TMP_SUM3_entry(const TMP_SUM3_entry& other) : C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM3_entry(const std::vector<std::string>& f, const RingFactorizedRelation<1, int32_t>& v) {
        /* if (f.size() < 1) return; */
        C = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM3_entry& modify(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM3_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM3_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM3_entry& x, const TMP_SUM3_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<TMP_SUM3_entry, RingFactorizedRelation<1, int32_t>, 
    PrimaryHashIndex<TMP_SUM3_entry, TMP_SUM3_mapkey0_idxfn>
  > TMP_SUM3_map;
  
  
  struct TMP_SUM4_entry {
    int32_t C; RingFactorizedRelation<1, int32_t> __av; TMP_SUM4_entry* nxt; TMP_SUM4_entry* prv;
  
    explicit TMP_SUM4_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM4_entry(const int32_t c0, const RingFactorizedRelation<1, int32_t>& c1) { C = c0; __av = c1;  }
    TMP_SUM4_entry(const TMP_SUM4_entry& other) : C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM4_entry(const std::vector<std::string>& f, const RingFactorizedRelation<1, int32_t>& v) {
        /* if (f.size() < 1) return; */
        C = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM4_entry& modify(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM4_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM4_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM4_entry& x, const TMP_SUM4_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<TMP_SUM4_entry, RingFactorizedRelation<1, int32_t>, 
    PrimaryHashIndex<TMP_SUM4_entry, TMP_SUM4_mapkey0_idxfn>
  > TMP_SUM4_map;
  
  
  struct TMP_SUM5_entry {
    int32_t D; RingFactorizedRelation<4, int32_t> __av; TMP_SUM5_entry* nxt; TMP_SUM5_entry* prv;
  
    explicit TMP_SUM5_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM5_entry(const int32_t c0, const RingFactorizedRelation<4, int32_t>& c1) { D = c0; __av = c1;  }
    TMP_SUM5_entry(const TMP_SUM5_entry& other) : D(other.D), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM5_entry(const std::vector<std::string>& f, const RingFactorizedRelation<4, int32_t>& v) {
        /* if (f.size() < 1) return; */
        D = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM5_entry& modify(const int32_t c0) { D = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, D);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM5_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM5_entry& e) {
      size_t h = 0;
      hash_combine(h, e.D);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM5_entry& x, const TMP_SUM5_entry& y) {
      return x.D == y.D;
    }
  };
  
  typedef MultiHashMap<TMP_SUM5_entry, RingFactorizedRelation<4, int32_t>, 
    PrimaryHashIndex<TMP_SUM5_entry, TMP_SUM5_mapkey0_idxfn>
  > TMP_SUM5_map;
  
  
  struct TMP_SUM6_entry {
    int32_t C; RingFactorizedRelation<3, int32_t> __av; TMP_SUM6_entry* nxt; TMP_SUM6_entry* prv;
  
    explicit TMP_SUM6_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM6_entry(const int32_t c0, const RingFactorizedRelation<3, int32_t>& c1) { C = c0; __av = c1;  }
    TMP_SUM6_entry(const TMP_SUM6_entry& other) : C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM6_entry(const std::vector<std::string>& f, const RingFactorizedRelation<3, int32_t>& v) {
        /* if (f.size() < 1) return; */
        C = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM6_entry& modify(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM6_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM6_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM6_entry& x, const TMP_SUM6_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<TMP_SUM6_entry, RingFactorizedRelation<3, int32_t>, 
    PrimaryHashIndex<TMP_SUM6_entry, TMP_SUM6_mapkey0_idxfn>
  > TMP_SUM6_map;
  
  
  struct TMP_SUM7_entry {
    int32_t D; int32_t E; RingFactorizedRelation<5, int32_t> __av; TMP_SUM7_entry* nxt; TMP_SUM7_entry* prv;
  
    explicit TMP_SUM7_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM7_entry(const int32_t c0, const int32_t c1, const RingFactorizedRelation<5, int32_t>& c2) { D = c0; E = c1; __av = c2;  }
    TMP_SUM7_entry(const TMP_SUM7_entry& other) : D(other.D), E(other.E), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM7_entry(const std::vector<std::string>& f, const RingFactorizedRelation<5, int32_t>& v) {
        /* if (f.size() < 2) return; */
        D = std::stoi(f[0]); E = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM7_entry& modify(const int32_t c0, const int32_t c1) { D = c0; E = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, D);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, E);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM7_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM7_entry& e) {
      size_t h = 0;
      hash_combine(h, e.D);
      hash_combine(h, e.E);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM7_entry& x, const TMP_SUM7_entry& y) {
      return x.D == y.D && x.E == y.E;
    }
  };
  
  typedef MultiHashMap<TMP_SUM7_entry, RingFactorizedRelation<5, int32_t>, 
    PrimaryHashIndex<TMP_SUM7_entry, TMP_SUM7_mapkey01_idxfn>
  > TMP_SUM7_map;
  
  
  struct TMP_SUM8_entry {
    int32_t D; RingFactorizedRelation<4, int32_t> __av; TMP_SUM8_entry* nxt; TMP_SUM8_entry* prv;
  
    explicit TMP_SUM8_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM8_entry(const int32_t c0, const RingFactorizedRelation<4, int32_t>& c1) { D = c0; __av = c1;  }
    TMP_SUM8_entry(const TMP_SUM8_entry& other) : D(other.D), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM8_entry(const std::vector<std::string>& f, const RingFactorizedRelation<4, int32_t>& v) {
        /* if (f.size() < 1) return; */
        D = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM8_entry& modify(const int32_t c0) { D = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, D);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM8_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM8_entry& e) {
      size_t h = 0;
      hash_combine(h, e.D);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM8_entry& x, const TMP_SUM8_entry& y) {
      return x.D == y.D;
    }
  };
  
  typedef MultiHashMap<TMP_SUM8_entry, RingFactorizedRelation<4, int32_t>, 
    PrimaryHashIndex<TMP_SUM8_entry, TMP_SUM8_mapkey0_idxfn>
  > TMP_SUM8_map;
  
  
  struct TMP_SUM9_entry {
    int32_t C; RingFactorizedRelation<3, int32_t> __av; TMP_SUM9_entry* nxt; TMP_SUM9_entry* prv;
  
    explicit TMP_SUM9_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM9_entry(const int32_t c0, const RingFactorizedRelation<3, int32_t>& c1) { C = c0; __av = c1;  }
    TMP_SUM9_entry(const TMP_SUM9_entry& other) : C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM9_entry(const std::vector<std::string>& f, const RingFactorizedRelation<3, int32_t>& v) {
        /* if (f.size() < 1) return; */
        C = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM9_entry& modify(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM9_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM9_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM9_entry& x, const TMP_SUM9_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<TMP_SUM9_entry, RingFactorizedRelation<3, int32_t>, 
    PrimaryHashIndex<TMP_SUM9_entry, TMP_SUM9_mapkey0_idxfn>
  > TMP_SUM9_map;
  
  
  struct TMP_SUM10_entry {
    int32_t C; int32_t A; RingFactorizedRelation<2, int32_t> __av; TMP_SUM10_entry* nxt; TMP_SUM10_entry* prv;
  
    explicit TMP_SUM10_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM10_entry(const int32_t c0, const int32_t c1, const RingFactorizedRelation<2, int32_t>& c2) { C = c0; A = c1; __av = c2;  }
    TMP_SUM10_entry(const TMP_SUM10_entry& other) : C(other.C), A(other.A), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM10_entry(const std::vector<std::string>& f, const RingFactorizedRelation<2, int32_t>& v) {
        /* if (f.size() < 2) return; */
        C = std::stoi(f[0]); A = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM10_entry& modify(const int32_t c0, const int32_t c1) { C = c0; A = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, A);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM10_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM10_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      hash_combine(h, e.A);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM10_entry& x, const TMP_SUM10_entry& y) {
      return x.C == y.C && x.A == y.A;
    }
  };
  
  typedef MultiHashMap<TMP_SUM10_entry, RingFactorizedRelation<2, int32_t>, 
    PrimaryHashIndex<TMP_SUM10_entry, TMP_SUM10_mapkey01_idxfn>
  > TMP_SUM10_map;
  
  
  struct TMP_SUM11_entry {
    int32_t C; RingFactorizedRelation<1, int32_t> __av; TMP_SUM11_entry* nxt; TMP_SUM11_entry* prv;
  
    explicit TMP_SUM11_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM11_entry(const int32_t c0, const RingFactorizedRelation<1, int32_t>& c1) { C = c0; __av = c1;  }
    TMP_SUM11_entry(const TMP_SUM11_entry& other) : C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM11_entry(const std::vector<std::string>& f, const RingFactorizedRelation<1, int32_t>& v) {
        /* if (f.size() < 1) return; */
        C = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM11_entry& modify(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM11_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM11_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM11_entry& x, const TMP_SUM11_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<TMP_SUM11_entry, RingFactorizedRelation<1, int32_t>, 
    PrimaryHashIndex<TMP_SUM11_entry, TMP_SUM11_mapkey0_idxfn>
  > TMP_SUM11_map;
  
  
  struct TMP_SUM12_entry {
    int32_t D; int32_t E; RingFactorizedRelation<5, int32_t> __av; TMP_SUM12_entry* nxt; TMP_SUM12_entry* prv;
  
    explicit TMP_SUM12_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM12_entry(const int32_t c0, const int32_t c1, const RingFactorizedRelation<5, int32_t>& c2) { D = c0; E = c1; __av = c2;  }
    TMP_SUM12_entry(const TMP_SUM12_entry& other) : D(other.D), E(other.E), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM12_entry(const std::vector<std::string>& f, const RingFactorizedRelation<5, int32_t>& v) {
        /* if (f.size() < 2) return; */
        D = std::stoi(f[0]); E = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM12_entry& modify(const int32_t c0, const int32_t c1) { D = c0; E = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, D);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, E);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM12_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM12_entry& e) {
      size_t h = 0;
      hash_combine(h, e.D);
      hash_combine(h, e.E);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM12_entry& x, const TMP_SUM12_entry& y) {
      return x.D == y.D && x.E == y.E;
    }
  };
  
  typedef MultiHashMap<TMP_SUM12_entry, RingFactorizedRelation<5, int32_t>, 
    PrimaryHashIndex<TMP_SUM12_entry, TMP_SUM12_mapkey01_idxfn>
  > TMP_SUM12_map;
  
  
  struct TMP_SUM13_entry {
    int32_t D; RingFactorizedRelation<4, int32_t> __av; TMP_SUM13_entry* nxt; TMP_SUM13_entry* prv;
  
    explicit TMP_SUM13_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM13_entry(const int32_t c0, const RingFactorizedRelation<4, int32_t>& c1) { D = c0; __av = c1;  }
    TMP_SUM13_entry(const TMP_SUM13_entry& other) : D(other.D), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM13_entry(const std::vector<std::string>& f, const RingFactorizedRelation<4, int32_t>& v) {
        /* if (f.size() < 1) return; */
        D = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM13_entry& modify(const int32_t c0) { D = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, D);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM13_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM13_entry& e) {
      size_t h = 0;
      hash_combine(h, e.D);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM13_entry& x, const TMP_SUM13_entry& y) {
      return x.D == y.D;
    }
  };
  
  typedef MultiHashMap<TMP_SUM13_entry, RingFactorizedRelation<4, int32_t>, 
    PrimaryHashIndex<TMP_SUM13_entry, TMP_SUM13_mapkey0_idxfn>
  > TMP_SUM13_map;
  
  
  struct TMP_SUM14_entry {
    int32_t C; RingFactorizedRelation<3, int32_t> __av; TMP_SUM14_entry* nxt; TMP_SUM14_entry* prv;
  
    explicit TMP_SUM14_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM14_entry(const int32_t c0, const RingFactorizedRelation<3, int32_t>& c1) { C = c0; __av = c1;  }
    TMP_SUM14_entry(const TMP_SUM14_entry& other) : C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM14_entry(const std::vector<std::string>& f, const RingFactorizedRelation<3, int32_t>& v) {
        /* if (f.size() < 1) return; */
        C = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM14_entry& modify(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM14_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM14_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM14_entry& x, const TMP_SUM14_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<TMP_SUM14_entry, RingFactorizedRelation<3, int32_t>, 
    PrimaryHashIndex<TMP_SUM14_entry, TMP_SUM14_mapkey0_idxfn>
  > TMP_SUM14_map;
  
  
  struct DELTA_M_entry {
    int32_t c; int32_t d; int64_t __av; DELTA_M_entry* nxt; DELTA_M_entry* prv;
  
    explicit DELTA_M_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_M_entry(const int32_t c0, const int32_t c1, const int64_t c2) { c = c0; d = c1; __av = c2;  }
    DELTA_M_entry(const DELTA_M_entry& other) : c(other.c), d(other.d), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_M_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        c = std::stoi(f[0]); d = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_M_entry& modify(const int32_t c0, const int32_t c1) { c = c0; d = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, d);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_M_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_M_entry& e) {
      size_t h = 0;
      hash_combine(h, e.c);
      hash_combine(h, e.d);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_M_entry& x, const DELTA_M_entry& y) {
      return x.c == y.c && x.d == y.d;
    }
  };
  
  typedef MultiHashMap<DELTA_M_entry, int64_t, 
    PrimaryHashIndex<DELTA_M_entry, DELTA_M_mapkey01_idxfn>
  > DELTA_M_map;
  
  
  struct DELTA_LBC_entry {
    int32_t b; int32_t c; int64_t __av; DELTA_LBC_entry* nxt; DELTA_LBC_entry* prv;
  
    explicit DELTA_LBC_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_LBC_entry(const int32_t c0, const int32_t c1, const int64_t c2) { b = c0; c = c1; __av = c2;  }
    DELTA_LBC_entry(const DELTA_LBC_entry& other) : b(other.b), c(other.c), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_LBC_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        b = std::stoi(f[0]); c = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_LBC_entry& modify(const int32_t c0, const int32_t c1) { b = c0; c = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_LBC_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_LBC_entry& e) {
      size_t h = 0;
      hash_combine(h, e.b);
      hash_combine(h, e.c);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_LBC_entry& x, const DELTA_LBC_entry& y) {
      return x.b == y.b && x.c == y.c;
    }
  };
  
  typedef MultiHashMap<DELTA_LBC_entry, int64_t, 
    PrimaryHashIndex<DELTA_LBC_entry, DELTA_LBC_mapkey01_idxfn>
  > DELTA_LBC_map;
  
  
  struct DELTA_LCA_entry {
    int32_t c; int32_t a; int64_t __av; DELTA_LCA_entry* nxt; DELTA_LCA_entry* prv;
  
    explicit DELTA_LCA_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_LCA_entry(const int32_t c0, const int32_t c1, const int64_t c2) { c = c0; a = c1; __av = c2;  }
    DELTA_LCA_entry(const DELTA_LCA_entry& other) : c(other.c), a(other.a), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_LCA_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        c = std::stoi(f[0]); a = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_LCA_entry& modify(const int32_t c0, const int32_t c1) { c = c0; a = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_LCA_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_LCA_entry& e) {
      size_t h = 0;
      hash_combine(h, e.c);
      hash_combine(h, e.a);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_LCA_entry& x, const DELTA_LCA_entry& y) {
      return x.c == y.c && x.a == y.a;
    }
  };
  
  typedef MultiHashMap<DELTA_LCA_entry, int64_t, 
    PrimaryHashIndex<DELTA_LCA_entry, DELTA_LCA_mapkey01_idxfn>
  > DELTA_LCA_map;
  
  
  struct DELTA_RDE_entry {
    int32_t d; int32_t e; int64_t __av; DELTA_RDE_entry* nxt; DELTA_RDE_entry* prv;
  
    explicit DELTA_RDE_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_RDE_entry(const int32_t c0, const int32_t c1, const int64_t c2) { d = c0; e = c1; __av = c2;  }
    DELTA_RDE_entry(const DELTA_RDE_entry& other) : d(other.d), e(other.e), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_RDE_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        d = std::stoi(f[0]); e = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_RDE_entry& modify(const int32_t c0, const int32_t c1) { d = c0; e = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, d);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, e);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_RDE_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_RDE_entry& e) {
      size_t h = 0;
      hash_combine(h, e.d);
      hash_combine(h, e.e);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_RDE_entry& x, const DELTA_RDE_entry& y) {
      return x.d == y.d && x.e == y.e;
    }
  };
  
  typedef MultiHashMap<DELTA_RDE_entry, int64_t, 
    PrimaryHashIndex<DELTA_RDE_entry, DELTA_RDE_mapkey01_idxfn>
  > DELTA_RDE_map;
  
  
  struct DELTA_RFD_entry {
    int32_t ff; int32_t d; int64_t __av; DELTA_RFD_entry* nxt; DELTA_RFD_entry* prv;
  
    explicit DELTA_RFD_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_RFD_entry(const int32_t c0, const int32_t c1, const int64_t c2) { ff = c0; d = c1; __av = c2;  }
    DELTA_RFD_entry(const DELTA_RFD_entry& other) : ff(other.ff), d(other.d), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_RFD_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        ff = std::stoi(f[0]); d = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_RFD_entry& modify(const int32_t c0, const int32_t c1) { ff = c0; d = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, ff);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, d);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_RFD_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_RFD_entry& e) {
      size_t h = 0;
      hash_combine(h, e.ff);
      hash_combine(h, e.d);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_RFD_entry& x, const DELTA_RFD_entry& y) {
      return x.ff == y.ff && x.d == y.d;
    }
  };
  
  typedef MultiHashMap<DELTA_RFD_entry, int64_t, 
    PrimaryHashIndex<DELTA_RFD_entry, DELTA_RFD_mapkey01_idxfn>
  > DELTA_RFD_map;
  
  
  struct DELTA_LAB_entry {
    int32_t a; int32_t b; int64_t __av; DELTA_LAB_entry* nxt; DELTA_LAB_entry* prv;
  
    explicit DELTA_LAB_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_LAB_entry(const int32_t c0, const int32_t c1, const int64_t c2) { a = c0; b = c1; __av = c2;  }
    DELTA_LAB_entry(const DELTA_LAB_entry& other) : a(other.a), b(other.b), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_LAB_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        a = std::stoi(f[0]); b = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_LAB_entry& modify(const int32_t c0, const int32_t c1) { a = c0; b = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_LAB_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_LAB_entry& e) {
      size_t h = 0;
      hash_combine(h, e.a);
      hash_combine(h, e.b);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_LAB_entry& x, const DELTA_LAB_entry& y) {
      return x.a == y.a && x.b == y.b;
    }
  };
  
  typedef MultiHashMap<DELTA_LAB_entry, int64_t, 
    PrimaryHashIndex<DELTA_LAB_entry, DELTA_LAB_mapkey01_idxfn>
  > DELTA_LAB_map;
  
  
  struct DELTA_REF_entry {
    int32_t e; int32_t ff; int64_t __av; DELTA_REF_entry* nxt; DELTA_REF_entry* prv;
  
    explicit DELTA_REF_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_REF_entry(const int32_t c0, const int32_t c1, const int64_t c2) { e = c0; ff = c1; __av = c2;  }
    DELTA_REF_entry(const DELTA_REF_entry& other) : e(other.e), ff(other.ff), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_REF_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        e = std::stoi(f[0]); ff = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_REF_entry& modify(const int32_t c0, const int32_t c1) { e = c0; ff = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, e);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, ff);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_REF_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_REF_entry& e) {
      size_t h = 0;
      hash_combine(h, e.e);
      hash_combine(h, e.ff);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_REF_entry& x, const DELTA_REF_entry& y) {
      return x.e == y.e && x.ff == y.ff;
    }
  };
  
  typedef MultiHashMap<DELTA_REF_entry, int64_t, 
    PrimaryHashIndex<DELTA_REF_entry, DELTA_REF_mapkey01_idxfn>
  > DELTA_REF_map;

  

  /* Defines top-level materialized views */
  struct tlq_t {
    struct timeval t0, t; 
    size_t tT, tN, tS;
  
    tlq_t(): tN(0), tS(0) , V_C_LLLRRRM1(RingFactorizedRelation<0, int32_t>()) { 
      gettimeofday(&t0, NULL); 
    }
  
    /* Serialization code */
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << "\n";
      const RingFactorizedRelation<0, int32_t>& _V_C_LLLRRRM1 = get_V_C_LLLRRRM1();
      dbtoaster::serialize_nvp_tabbed(ar, STRING(V_C_LLLRRRM1), _V_C_LLLRRRM1, "\t");
      
      ar << "\n";
      const V_A_LLL1_map& _V_A_LLL1 = get_V_A_LLL1();
      dbtoaster::serialize_nvp_tabbed(ar, STRING(V_A_LLL1), _V_A_LLL1, "\t");
      
      ar << "\n";
      const V_B_LL1_map& _V_B_LL1 = get_V_B_LL1();
      dbtoaster::serialize_nvp_tabbed(ar, STRING(V_B_LL1), _V_B_LL1, "\t");
      
      ar << "\n";
      const V_D_RRRM1_map& _V_D_RRRM1 = get_V_D_RRRM1();
      dbtoaster::serialize_nvp_tabbed(ar, STRING(V_D_RRRM1), _V_D_RRRM1, "\t");
      
      ar << "\n";
      const V_E_RRR1_map& _V_E_RRR1 = get_V_E_RRR1();
      dbtoaster::serialize_nvp_tabbed(ar, STRING(V_E_RRR1), _V_E_RRR1, "\t");
      
      ar << "\n";
      const V_FF_RR1_map& _V_FF_RR1 = get_V_FF_RR1();
      dbtoaster::serialize_nvp_tabbed(ar, STRING(V_FF_RR1), _V_FF_RR1, "\t");
    }
  
    /* Functions returning / computing the results of top level queries */
    const RingFactorizedRelation<0, int32_t>& get_V_C_LLLRRRM1() const {
      return V_C_LLLRRRM1;
    }
    
    const V_A_LLL1_map& get_V_A_LLL1() const {
      return V_A_LLL1;
    }
    
    const V_B_LL1_map& get_V_B_LL1() const {
      return V_B_LL1;
    }
    
    const V_D_RRRM1_map& get_V_D_RRRM1() const {
      return V_D_RRRM1;
    }
    
    const V_E_RRR1_map& get_V_E_RRR1() const {
      return V_E_RRR1;
    }
    
    const V_FF_RR1_map& get_V_FF_RR1() const {
      return V_FF_RR1;
    }
  
  protected:
    /* Data structures used for storing / computing top-level queries */
    RingFactorizedRelation<0, int32_t> V_C_LLLRRRM1;
    V_A_LLL1_map V_A_LLL1;
    V_B_LL1_map V_B_LL1;
    V_D_RRRM1_map V_D_RRRM1;
    V_E_RRR1_map V_E_RRR1;
    V_FF_RR1_map V_FF_RR1;
    
  };

  /* Contains materialized views and processing (IVM) logic */
  struct data_t : tlq_t {
  
    data_t(): tlq_t() {
      
      
    }
  
    
  
    
  
    /* Trigger functions for table relations */
    
    
    /* Trigger functions for stream relations */
    void on_batch_update_M(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM1.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& d = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v1 = chunk.payload[i];
          TMP_SUM1.addOrDelOnZero(se1.modify(c), ((v1 * V_E_RRR1.getValueOrDefault(se2.modify(d))) * Ulift<3>(d)));
        }
      }
      
      { //foreach
        TMP_SUM1_entry* e2 = TMP_SUM1.head;
        while (e2) {
          int32_t c = e2->C;
          RingFactorizedRelation<3, int32_t>& v2 = e2->__av;
          V_C_LLLRRRM1 += ((v2 * V_A_LLL1.getValueOrDefault(se4.modify(c))) * Ulift<0>(c));
          e2 = e2->nxt;
        }
      }
      
      { //foreach
        TMP_SUM1_entry* e3 = TMP_SUM1.head;
        while (e3) {
          int32_t c = e3->C;
          RingFactorizedRelation<3, int32_t>& v3 = e3->__av;
          V_D_RRRM1.addOrDelOnZero(se5.modify(c), v3);
          e3 = e3->nxt;
        }
      }
      
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& d = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v4 = chunk.payload[i];
          V_M_M1.addOrDelOnZero(se6.modify(c, d), v4);
        }
      }
    }
    
    
    void on_batch_update_LBC(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM2.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& b = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v5 = chunk.payload[i];
          { //slice
            const LinkedNode<V_LAB_L1_entry>* n1 = static_cast<const LinkedNode<V_LAB_L1_entry>*>(V_LAB_L1.slice(se8.modify1(b), 0));
            V_LAB_L1_entry* e6;
            while (n1) {
              e6 = n1->obj;
              int32_t a = e6->A;
              int64_t v6 = e6->__av;
              TMP_SUM2.addOrDelOnZero(se7.modify(c, a), ((v5 * v6) * Ulift<2>(b)));
              n1 = n1->next;
            }
          }
        }
      }
      
      TMP_SUM3.clear();
      { //foreach
        TMP_SUM2_entry* e7 = TMP_SUM2.head;
        while (e7) {
          int32_t c = e7->C;
          int32_t a = e7->A;
          RingFactorizedRelation<2, int32_t>& v7 = e7->__av;
          TMP_SUM3.addOrDelOnZero(se9.modify(c), ((v7 * V_LCA_L1.getValueOrDefault(se10.modify(c, a))) * Ulift<1>(a)));
          e7 = e7->nxt;
        }
      }
      
      { //foreach
        TMP_SUM3_entry* e8 = TMP_SUM3.head;
        while (e8) {
          int32_t c = e8->C;
          RingFactorizedRelation<1, int32_t>& v8 = e8->__av;
          V_C_LLLRRRM1 += ((v8 * V_D_RRRM1.getValueOrDefault(se12.modify(c))) * Ulift<0>(c));
          e8 = e8->nxt;
        }
      }
      
      { //foreach
        TMP_SUM3_entry* e9 = TMP_SUM3.head;
        while (e9) {
          int32_t c = e9->C;
          RingFactorizedRelation<1, int32_t>& v9 = e9->__av;
          V_A_LLL1.addOrDelOnZero(se13.modify(c), v9);
          e9 = e9->nxt;
        }
      }
      
      { //foreach
        TMP_SUM2_entry* e10 = TMP_SUM2.head;
        while (e10) {
          int32_t c = e10->C;
          int32_t a = e10->A;
          RingFactorizedRelation<2, int32_t>& v10 = e10->__av;
          V_B_LL1.addOrDelOnZero(se14.modify(c, a), v10);
          e10 = e10->nxt;
        }
      }
      
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& b = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v11 = chunk.payload[i];
          V_LBC_L1.addOrDelOnZero(se15.modify(b, c), v11);
        }
      }
    }
    
    
    void on_batch_update_LCA(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM4.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& a = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v12 = chunk.payload[i];
          TMP_SUM4.addOrDelOnZero(se16.modify(c), ((v12 * V_B_LL1.getValueOrDefault(se17.modify(c, a))) * Ulift<1>(a)));
        }
      }
      
      { //foreach
        TMP_SUM4_entry* e13 = TMP_SUM4.head;
        while (e13) {
          int32_t c = e13->C;
          RingFactorizedRelation<1, int32_t>& v13 = e13->__av;
          V_C_LLLRRRM1 += ((v13 * V_D_RRRM1.getValueOrDefault(se19.modify(c))) * Ulift<0>(c));
          e13 = e13->nxt;
        }
      }
      
      { //foreach
        TMP_SUM4_entry* e14 = TMP_SUM4.head;
        while (e14) {
          int32_t c = e14->C;
          RingFactorizedRelation<1, int32_t>& v14 = e14->__av;
          V_A_LLL1.addOrDelOnZero(se20.modify(c), v14);
          e14 = e14->nxt;
        }
      }
      
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& a = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v15 = chunk.payload[i];
          V_LCA_L1.addOrDelOnZero(se21.modify(c, a), v15);
        }
      }
    }
    
    
    void on_batch_update_RDE(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM5.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& d = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& e = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v16 = chunk.payload[i];
          TMP_SUM5.addOrDelOnZero(se22.modify(d), ((v16 * V_FF_RR1.getValueOrDefault(se23.modify(d, e))) * Ulift<4>(e)));
        }
      }
      
      TMP_SUM6.clear();
      { //foreach
        TMP_SUM5_entry* e17 = TMP_SUM5.head;
        while (e17) {
          int32_t d = e17->D;
          RingFactorizedRelation<4, int32_t>& v17 = e17->__av;
          { //slice
            const LinkedNode<V_M_M1_entry>* n2 = static_cast<const LinkedNode<V_M_M1_entry>*>(V_M_M1.slice(se25.modify1(d), 0));
            V_M_M1_entry* e18;
            while (n2) {
              e18 = n2->obj;
              int32_t c = e18->C;
              int64_t v18 = e18->__av;
              TMP_SUM6.addOrDelOnZero(se24.modify(c), ((v17 * v18) * Ulift<3>(d)));
              n2 = n2->next;
            }
          }
          e17 = e17->nxt;
        }
      }
      
      { //foreach
        TMP_SUM6_entry* e19 = TMP_SUM6.head;
        while (e19) {
          int32_t c = e19->C;
          RingFactorizedRelation<3, int32_t>& v19 = e19->__av;
          V_C_LLLRRRM1 += ((v19 * V_A_LLL1.getValueOrDefault(se27.modify(c))) * Ulift<0>(c));
          e19 = e19->nxt;
        }
      }
      
      { //foreach
        TMP_SUM6_entry* e20 = TMP_SUM6.head;
        while (e20) {
          int32_t c = e20->C;
          RingFactorizedRelation<3, int32_t>& v20 = e20->__av;
          V_D_RRRM1.addOrDelOnZero(se28.modify(c), v20);
          e20 = e20->nxt;
        }
      }
      
      { //foreach
        TMP_SUM5_entry* e21 = TMP_SUM5.head;
        while (e21) {
          int32_t d = e21->D;
          RingFactorizedRelation<4, int32_t>& v21 = e21->__av;
          V_E_RRR1.addOrDelOnZero(se29.modify(d), v21);
          e21 = e21->nxt;
        }
      }
      
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& d = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& e = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v22 = chunk.payload[i];
          V_RDE_R1.addOrDelOnZero(se30.modify(d, e), v22);
        }
      }
    }
    
    
    void on_batch_update_RFD(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM7.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& ff = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& d = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v23 = chunk.payload[i];
          { //slice
            const LinkedNode<V_REF_R1_entry>* n3 = static_cast<const LinkedNode<V_REF_R1_entry>*>(V_REF_R1.slice(se32.modify1(ff), 0));
            V_REF_R1_entry* e24;
            while (n3) {
              e24 = n3->obj;
              int32_t e = e24->E;
              int64_t v24 = e24->__av;
              TMP_SUM7.addOrDelOnZero(se31.modify(d, e), ((v23 * v24) * Ulift<5>(ff)));
              n3 = n3->next;
            }
          }
        }
      }
      
      TMP_SUM8.clear();
      { //foreach
        TMP_SUM7_entry* e25 = TMP_SUM7.head;
        while (e25) {
          int32_t d = e25->D;
          int32_t e = e25->E;
          RingFactorizedRelation<5, int32_t>& v25 = e25->__av;
          TMP_SUM8.addOrDelOnZero(se33.modify(d), ((v25 * V_RDE_R1.getValueOrDefault(se34.modify(d, e))) * Ulift<4>(e)));
          e25 = e25->nxt;
        }
      }
      
      TMP_SUM9.clear();
      { //foreach
        TMP_SUM8_entry* e26 = TMP_SUM8.head;
        while (e26) {
          int32_t d = e26->D;
          RingFactorizedRelation<4, int32_t>& v26 = e26->__av;
          { //slice
            const LinkedNode<V_M_M1_entry>* n4 = static_cast<const LinkedNode<V_M_M1_entry>*>(V_M_M1.slice(se36.modify1(d), 0));
            V_M_M1_entry* e27;
            while (n4) {
              e27 = n4->obj;
              int32_t c = e27->C;
              int64_t v27 = e27->__av;
              TMP_SUM9.addOrDelOnZero(se35.modify(c), ((v26 * v27) * Ulift<3>(d)));
              n4 = n4->next;
            }
          }
          e26 = e26->nxt;
        }
      }
      
      { //foreach
        TMP_SUM9_entry* e28 = TMP_SUM9.head;
        while (e28) {
          int32_t c = e28->C;
          RingFactorizedRelation<3, int32_t>& v28 = e28->__av;
          V_C_LLLRRRM1 += ((v28 * V_A_LLL1.getValueOrDefault(se38.modify(c))) * Ulift<0>(c));
          e28 = e28->nxt;
        }
      }
      
      { //foreach
        TMP_SUM9_entry* e29 = TMP_SUM9.head;
        while (e29) {
          int32_t c = e29->C;
          RingFactorizedRelation<3, int32_t>& v29 = e29->__av;
          V_D_RRRM1.addOrDelOnZero(se39.modify(c), v29);
          e29 = e29->nxt;
        }
      }
      
      { //foreach
        TMP_SUM8_entry* e30 = TMP_SUM8.head;
        while (e30) {
          int32_t d = e30->D;
          RingFactorizedRelation<4, int32_t>& v30 = e30->__av;
          V_E_RRR1.addOrDelOnZero(se40.modify(d), v30);
          e30 = e30->nxt;
        }
      }
      
      { //foreach
        TMP_SUM7_entry* e31 = TMP_SUM7.head;
        while (e31) {
          int32_t d = e31->D;
          int32_t e = e31->E;
          RingFactorizedRelation<5, int32_t>& v31 = e31->__av;
          V_FF_RR1.addOrDelOnZero(se41.modify(d, e), v31);
          e31 = e31->nxt;
        }
      }
      
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& ff = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& d = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v32 = chunk.payload[i];
          V_RFD_R1.addOrDelOnZero(se42.modify(ff, d), v32);
        }
      }
    }
    
    
    void on_batch_update_LAB(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM10.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& a = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& b = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v33 = chunk.payload[i];
          { //slice
            const LinkedNode<V_LBC_L1_entry>* n5 = static_cast<const LinkedNode<V_LBC_L1_entry>*>(V_LBC_L1.slice(se44.modify0(b), 0));
            V_LBC_L1_entry* e34;
            while (n5) {
              e34 = n5->obj;
              int32_t c = e34->C;
              int64_t v34 = e34->__av;
              TMP_SUM10.addOrDelOnZero(se43.modify(c, a), ((v33 * v34) * Ulift<2>(b)));
              n5 = n5->next;
            }
          }
        }
      }
      
      TMP_SUM11.clear();
      { //foreach
        TMP_SUM10_entry* e35 = TMP_SUM10.head;
        while (e35) {
          int32_t c = e35->C;
          int32_t a = e35->A;
          RingFactorizedRelation<2, int32_t>& v35 = e35->__av;
          TMP_SUM11.addOrDelOnZero(se45.modify(c), ((v35 * V_LCA_L1.getValueOrDefault(se46.modify(c, a))) * Ulift<1>(a)));
          e35 = e35->nxt;
        }
      }
      
      { //foreach
        TMP_SUM11_entry* e36 = TMP_SUM11.head;
        while (e36) {
          int32_t c = e36->C;
          RingFactorizedRelation<1, int32_t>& v36 = e36->__av;
          V_C_LLLRRRM1 += ((v36 * V_D_RRRM1.getValueOrDefault(se48.modify(c))) * Ulift<0>(c));
          e36 = e36->nxt;
        }
      }
      
      { //foreach
        TMP_SUM11_entry* e37 = TMP_SUM11.head;
        while (e37) {
          int32_t c = e37->C;
          RingFactorizedRelation<1, int32_t>& v37 = e37->__av;
          V_A_LLL1.addOrDelOnZero(se49.modify(c), v37);
          e37 = e37->nxt;
        }
      }
      
      { //foreach
        TMP_SUM10_entry* e38 = TMP_SUM10.head;
        while (e38) {
          int32_t c = e38->C;
          int32_t a = e38->A;
          RingFactorizedRelation<2, int32_t>& v38 = e38->__av;
          V_B_LL1.addOrDelOnZero(se50.modify(c, a), v38);
          e38 = e38->nxt;
        }
      }
      
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& a = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& b = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v39 = chunk.payload[i];
          V_LAB_L1.addOrDelOnZero(se51.modify(a, b), v39);
        }
      }
    }
    
    
    void on_batch_update_REF(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM12.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& e = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& ff = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v40 = chunk.payload[i];
          { //slice
            const LinkedNode<V_RFD_R1_entry>* n6 = static_cast<const LinkedNode<V_RFD_R1_entry>*>(V_RFD_R1.slice(se53.modify0(ff), 0));
            V_RFD_R1_entry* e41;
            while (n6) {
              e41 = n6->obj;
              int32_t d = e41->D;
              int64_t v41 = e41->__av;
              TMP_SUM12.addOrDelOnZero(se52.modify(d, e), ((v40 * v41) * Ulift<5>(ff)));
              n6 = n6->next;
            }
          }
        }
      }
      
      TMP_SUM13.clear();
      { //foreach
        TMP_SUM12_entry* e42 = TMP_SUM12.head;
        while (e42) {
          int32_t d = e42->D;
          int32_t e = e42->E;
          RingFactorizedRelation<5, int32_t>& v42 = e42->__av;
          TMP_SUM13.addOrDelOnZero(se54.modify(d), ((v42 * V_RDE_R1.getValueOrDefault(se55.modify(d, e))) * Ulift<4>(e)));
          e42 = e42->nxt;
        }
      }
      
      TMP_SUM14.clear();
      { //foreach
        TMP_SUM13_entry* e43 = TMP_SUM13.head;
        while (e43) {
          int32_t d = e43->D;
          RingFactorizedRelation<4, int32_t>& v43 = e43->__av;
          { //slice
            const LinkedNode<V_M_M1_entry>* n7 = static_cast<const LinkedNode<V_M_M1_entry>*>(V_M_M1.slice(se57.modify1(d), 0));
            V_M_M1_entry* e44;
            while (n7) {
              e44 = n7->obj;
              int32_t c = e44->C;
              int64_t v44 = e44->__av;
              TMP_SUM14.addOrDelOnZero(se56.modify(c), ((v43 * v44) * Ulift<3>(d)));
              n7 = n7->next;
            }
          }
          e43 = e43->nxt;
        }
      }
      
      { //foreach
        TMP_SUM14_entry* e45 = TMP_SUM14.head;
        while (e45) {
          int32_t c = e45->C;
          RingFactorizedRelation<3, int32_t>& v45 = e45->__av;
          V_C_LLLRRRM1 += ((v45 * V_A_LLL1.getValueOrDefault(se59.modify(c))) * Ulift<0>(c));
          e45 = e45->nxt;
        }
      }
      
      { //foreach
        TMP_SUM14_entry* e46 = TMP_SUM14.head;
        while (e46) {
          int32_t c = e46->C;
          RingFactorizedRelation<3, int32_t>& v46 = e46->__av;
          V_D_RRRM1.addOrDelOnZero(se60.modify(c), v46);
          e46 = e46->nxt;
        }
      }
      
      { //foreach
        TMP_SUM13_entry* e47 = TMP_SUM13.head;
        while (e47) {
          int32_t d = e47->D;
          RingFactorizedRelation<4, int32_t>& v47 = e47->__av;
          V_E_RRR1.addOrDelOnZero(se61.modify(d), v47);
          e47 = e47->nxt;
        }
      }
      
      { //foreach
        TMP_SUM12_entry* e48 = TMP_SUM12.head;
        while (e48) {
          int32_t d = e48->D;
          int32_t e = e48->E;
          RingFactorizedRelation<5, int32_t>& v48 = e48->__av;
          V_FF_RR1.addOrDelOnZero(se62.modify(d, e), v48);
          e48 = e48->nxt;
        }
      }
      
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& e = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& ff = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v49 = chunk.payload[i];
          V_REF_R1.addOrDelOnZero(se63.modify(e, ff), v49);
        }
      }
    }
    
    
    void on_system_ready_event() {
      
    }
  
  private:
    
      /* Preallocated map entries (to avoid recreation of temporary objects) */
      TMP_SUM1_entry se1;
      V_E_RRR1_entry se2;
      V_A_LLL1_entry se4;
      V_D_RRRM1_entry se5;
      V_M_M1_entry se6;
      TMP_SUM2_entry se7;
      V_LAB_L1_entry se8;
      TMP_SUM3_entry se9;
      V_LCA_L1_entry se10;
      V_D_RRRM1_entry se12;
      V_A_LLL1_entry se13;
      V_B_LL1_entry se14;
      V_LBC_L1_entry se15;
      TMP_SUM4_entry se16;
      V_B_LL1_entry se17;
      V_D_RRRM1_entry se19;
      V_A_LLL1_entry se20;
      V_LCA_L1_entry se21;
      TMP_SUM5_entry se22;
      V_FF_RR1_entry se23;
      TMP_SUM6_entry se24;
      V_M_M1_entry se25;
      V_A_LLL1_entry se27;
      V_D_RRRM1_entry se28;
      V_E_RRR1_entry se29;
      V_RDE_R1_entry se30;
      TMP_SUM7_entry se31;
      V_REF_R1_entry se32;
      TMP_SUM8_entry se33;
      V_RDE_R1_entry se34;
      TMP_SUM9_entry se35;
      V_M_M1_entry se36;
      V_A_LLL1_entry se38;
      V_D_RRRM1_entry se39;
      V_E_RRR1_entry se40;
      V_FF_RR1_entry se41;
      V_RFD_R1_entry se42;
      TMP_SUM10_entry se43;
      V_LBC_L1_entry se44;
      TMP_SUM11_entry se45;
      V_LCA_L1_entry se46;
      V_D_RRRM1_entry se48;
      V_A_LLL1_entry se49;
      V_B_LL1_entry se50;
      V_LAB_L1_entry se51;
      TMP_SUM12_entry se52;
      V_RFD_R1_entry se53;
      TMP_SUM13_entry se54;
      V_RDE_R1_entry se55;
      TMP_SUM14_entry se56;
      V_M_M1_entry se57;
      V_A_LLL1_entry se59;
      V_D_RRRM1_entry se60;
      V_E_RRR1_entry se61;
      V_FF_RR1_entry se62;
      V_REF_R1_entry se63;
    
      
    
      /* Data structures used for storing materialized views */
      V_LBC_L1_map V_LBC_L1;
      V_LAB_L1_map V_LAB_L1;
      V_LCA_L1_map V_LCA_L1;
      V_RFD_R1_map V_RFD_R1;
      V_REF_R1_map V_REF_R1;
      V_RDE_R1_map V_RDE_R1;
      V_M_M1_map V_M_M1;
      TMP_SUM1_map TMP_SUM1;
      TMP_SUM2_map TMP_SUM2;
      TMP_SUM3_map TMP_SUM3;
      TMP_SUM4_map TMP_SUM4;
      TMP_SUM5_map TMP_SUM5;
      TMP_SUM6_map TMP_SUM6;
      TMP_SUM7_map TMP_SUM7;
      TMP_SUM8_map TMP_SUM8;
      TMP_SUM9_map TMP_SUM9;
      TMP_SUM10_map TMP_SUM10;
      TMP_SUM11_map TMP_SUM11;
      TMP_SUM12_map TMP_SUM12;
      TMP_SUM13_map TMP_SUM13;
      TMP_SUM14_map TMP_SUM14;
      DELTA_M_map DELTA_M;
      DELTA_LBC_map DELTA_LBC;
      DELTA_LCA_map DELTA_LCA;
      DELTA_RDE_map DELTA_RDE;
      DELTA_RFD_map DELTA_RFD;
      DELTA_LAB_map DELTA_LAB;
      DELTA_REF_map DELTA_REF;
    
      
    
  };

  

  namespace Config {
    static const std::vector<DataSourceConfig> DataSources = {
    {
      "M",
      true,
      DataSourceType::CSV,
      "unused.m",
      // schema
      {{"c", PrimitiveType::INT32}, {"d", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_M(chunk);
      }
    },
    {
      "LBC",
      true,
      DataSourceType::CSV,
      "unused.lbc",
      // schema
      {{"b", PrimitiveType::INT32}, {"c", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_LBC(chunk);
      }
    },
    {
      "LCA",
      true,
      DataSourceType::CSV,
      "unused.lca",
      // schema
      {{"c", PrimitiveType::INT32}, {"a", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_LCA(chunk);
      }
    },
    {
      "RDE",
      true,
      DataSourceType::CSV,
      "unused.rde",
      // schema
      {{"d", PrimitiveType::INT32}, {"e", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_RDE(chunk);
      }
    },
    {
      "RFD",
      true,
      DataSourceType::CSV,
      "unused.rfd",
      // schema
      {{"ff", PrimitiveType::INT32}, {"d", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_RFD(chunk);
      }
    },
    {
      "LAB",
      true,
      DataSourceType::CSV,
      "unused.lab",
      // schema
      {{"a", PrimitiveType::INT32}, {"b", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_LAB(chunk);
      }
    },
    {
      "REF",
      true,
      DataSourceType::CSV,
      "unused.ref",
      // schema
      {{"e", PrimitiveType::INT32}, {"ff", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_REF(chunk);
      }
    }
    };
  }

}