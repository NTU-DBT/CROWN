#include <sys/time.h>
#include <vector>
#include "dbtoaster/functions.hpp"
#include "dbtoaster/hash.hpp"
#include "dbtoaster/macro.hpp"
#include "dbtoaster/mmap.hpp"
#include "dbtoaster/serialization.hpp"
#include "dbtoaster/types.hpp"
#include "common.hpp"

#include "ring/ring_factorized.hpp"

#define RELATION_G1_DYNAMIC
#define RELATION_G2_DYNAMIC
#define RELATION_G3_DYNAMIC
#define RELATION_G4_DYNAMIC

namespace dbtoaster {

  /* Definitions of maps used for storing materialized views. */
  struct G1_entry {
    int32_t a; int32_t b; int64_t __av; G1_entry* nxt; G1_entry* prv;
  
    explicit G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit G1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { a = c0; b = c1; __av = c2;  }
    G1_entry(const G1_entry& other) : a(other.a), b(other.b), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        a = std::stoi(f[0]); b = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct G2_entry {
    int32_t b; int32_t c; int64_t __av; G2_entry* nxt; G2_entry* prv;
  
    explicit G2_entry() : nxt(nullptr), prv(nullptr) { }
    explicit G2_entry(const int32_t c0, const int32_t c1, const int64_t c2) { b = c0; c = c1; __av = c2;  }
    G2_entry(const G2_entry& other) : b(other.b), c(other.c), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    G2_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        b = std::stoi(f[0]); c = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct G3_entry {
    int32_t c; int32_t d; int64_t __av; G3_entry* nxt; G3_entry* prv;
  
    explicit G3_entry() : nxt(nullptr), prv(nullptr) { }
    explicit G3_entry(const int32_t c0, const int32_t c1, const int64_t c2) { c = c0; d = c1; __av = c2;  }
    G3_entry(const G3_entry& other) : c(other.c), d(other.d), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    G3_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        c = std::stoi(f[0]); d = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, d);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct G4_entry {
    int32_t d; int32_t e; int64_t __av; G4_entry* nxt; G4_entry* prv;
  
    explicit G4_entry() : nxt(nullptr), prv(nullptr) { }
    explicit G4_entry(const int32_t c0, const int32_t c1, const int64_t c2) { d = c0; e = c1; __av = c2;  }
    G4_entry(const G4_entry& other) : d(other.d), e(other.e), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    G4_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        d = std::stoi(f[0]); e = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, d);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, e);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  struct V_B_GG1_entry {
    int32_t C; RingFactorizedRelation<1, int32_t> __av; V_B_GG1_entry* nxt; V_B_GG1_entry* prv;
  
    explicit V_B_GG1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_B_GG1_entry(const int32_t c0, const RingFactorizedRelation<1, int32_t>& c1) { C = c0; __av = c1;  }
    V_B_GG1_entry(const V_B_GG1_entry& other) : C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_B_GG1_entry(const std::vector<std::string>& f, const RingFactorizedRelation<1, int32_t>& v) {
        /* if (f.size() < 1) return; */
        C = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_B_GG1_entry& modify(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_B_GG1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_B_GG1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_B_GG1_entry& x, const V_B_GG1_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<V_B_GG1_entry, RingFactorizedRelation<1, int32_t>, 
    PrimaryHashIndex<V_B_GG1_entry, V_B_GG1_mapkey0_idxfn>
  > V_B_GG1_map;
  
  
  struct V_A_G1_entry {
    int32_t B; int64_t __av; V_A_G1_entry* nxt; V_A_G1_entry* prv;
  
    explicit V_A_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_A_G1_entry(const int32_t c0, const int64_t c1) { B = c0; __av = c1;  }
    V_A_G1_entry(const V_A_G1_entry& other) : B(other.B), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_A_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        B = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_A_G1_entry& modify(const int32_t c0) { B = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_A_G1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_A_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_A_G1_entry& x, const V_A_G1_entry& y) {
      return x.B == y.B;
    }
  };
  
  typedef MultiHashMap<V_A_G1_entry, int64_t, 
    PrimaryHashIndex<V_A_G1_entry, V_A_G1_mapkey0_idxfn>
  > V_A_G1_map;
  
  
  struct V_G2_G1_entry {
    int32_t B; int32_t C; int64_t __av; V_G2_G1_entry* nxt; V_G2_G1_entry* prv;
  
    explicit V_G2_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_G2_G1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { B = c0; C = c1; __av = c2;  }
    V_G2_G1_entry(const V_G2_G1_entry& other) : B(other.B), C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_G2_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        B = std::stoi(f[0]); C = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_G2_G1_entry& modify(const int32_t c0, const int32_t c1) { B = c0; C = c1;  return *this; }
    FORCE_INLINE V_G2_G1_entry& modify0(const int32_t c0) { B = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_G2_G1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const V_G2_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_G2_G1_entry& x, const V_G2_G1_entry& y) {
      return x.B == y.B && x.C == y.C;
    }
  };
  
  struct V_G2_G1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_G2_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_G2_G1_entry& x, const V_G2_G1_entry& y) {
      return x.B == y.B;
    }
  };
  
  typedef MultiHashMap<V_G2_G1_entry, int64_t, 
    PrimaryHashIndex<V_G2_G1_entry, V_G2_G1_mapkey01_idxfn>,
    SecondaryHashIndex<V_G2_G1_entry, V_G2_G1_mapkey0_idxfn>
  > V_G2_G1_map;
  
  
  struct V_D_GG1_entry {
    int32_t C; RingFactorizedRelation<2, int32_t> __av; V_D_GG1_entry* nxt; V_D_GG1_entry* prv;
  
    explicit V_D_GG1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_D_GG1_entry(const int32_t c0, const RingFactorizedRelation<2, int32_t>& c1) { C = c0; __av = c1;  }
    V_D_GG1_entry(const V_D_GG1_entry& other) : C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_D_GG1_entry(const std::vector<std::string>& f, const RingFactorizedRelation<2, int32_t>& v) {
        /* if (f.size() < 1) return; */
        C = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_D_GG1_entry& modify(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_D_GG1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_D_GG1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_D_GG1_entry& x, const V_D_GG1_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<V_D_GG1_entry, RingFactorizedRelation<2, int32_t>, 
    PrimaryHashIndex<V_D_GG1_entry, V_D_GG1_mapkey0_idxfn>
  > V_D_GG1_map;
  
  
  struct V_E_G1_entry {
    int32_t D; int64_t __av; V_E_G1_entry* nxt; V_E_G1_entry* prv;
  
    explicit V_E_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_E_G1_entry(const int32_t c0, const int64_t c1) { D = c0; __av = c1;  }
    V_E_G1_entry(const V_E_G1_entry& other) : D(other.D), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_E_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        D = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_E_G1_entry& modify(const int32_t c0) { D = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, D);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_E_G1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_E_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.D);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_E_G1_entry& x, const V_E_G1_entry& y) {
      return x.D == y.D;
    }
  };
  
  typedef MultiHashMap<V_E_G1_entry, int64_t, 
    PrimaryHashIndex<V_E_G1_entry, V_E_G1_mapkey0_idxfn>
  > V_E_G1_map;
  
  
  struct V_G3_G1_entry {
    int32_t C; int32_t D; int64_t __av; V_G3_G1_entry* nxt; V_G3_G1_entry* prv;
  
    explicit V_G3_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_G3_G1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { C = c0; D = c1; __av = c2;  }
    V_G3_G1_entry(const V_G3_G1_entry& other) : C(other.C), D(other.D), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_G3_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        C = std::stoi(f[0]); D = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_G3_G1_entry& modify(const int32_t c0, const int32_t c1) { C = c0; D = c1;  return *this; }
    FORCE_INLINE V_G3_G1_entry& modify1(const int32_t c1) { D = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, D);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_G3_G1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const V_G3_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      hash_combine(h, e.D);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_G3_G1_entry& x, const V_G3_G1_entry& y) {
      return x.C == y.C && x.D == y.D;
    }
  };
  
  struct V_G3_G1_mapkey1_idxfn {
    FORCE_INLINE static size_t hash(const V_G3_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.D);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_G3_G1_entry& x, const V_G3_G1_entry& y) {
      return x.D == y.D;
    }
  };
  
  typedef MultiHashMap<V_G3_G1_entry, int64_t, 
    PrimaryHashIndex<V_G3_G1_entry, V_G3_G1_mapkey01_idxfn>,
    SecondaryHashIndex<V_G3_G1_entry, V_G3_G1_mapkey1_idxfn>
  > V_G3_G1_map;
  
  
  struct TMP_SUM1_entry {
    int32_t B; int64_t __av; TMP_SUM1_entry* nxt; TMP_SUM1_entry* prv;
  
    explicit TMP_SUM1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM1_entry(const int32_t c0, const int64_t c1) { B = c0; __av = c1;  }
    TMP_SUM1_entry(const TMP_SUM1_entry& other) : B(other.B), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        B = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM1_entry& modify(const int32_t c0) { B = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM1_entry& x, const TMP_SUM1_entry& y) {
      return x.B == y.B;
    }
  };
  
  typedef MultiHashMap<TMP_SUM1_entry, int64_t, 
    PrimaryHashIndex<TMP_SUM1_entry, TMP_SUM1_mapkey0_idxfn>
  > TMP_SUM1_map;
  
  
  struct TMP_SUM2_entry {
    int32_t C; RingFactorizedRelation<1, int32_t> __av; TMP_SUM2_entry* nxt; TMP_SUM2_entry* prv;
  
    explicit TMP_SUM2_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM2_entry(const int32_t c0, const RingFactorizedRelation<1, int32_t>& c1) { C = c0; __av = c1;  }
    TMP_SUM2_entry(const TMP_SUM2_entry& other) : C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM2_entry(const std::vector<std::string>& f, const RingFactorizedRelation<1, int32_t>& v) {
        /* if (f.size() < 1) return; */
        C = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM2_entry& modify(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM2_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM2_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM2_entry& x, const TMP_SUM2_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<TMP_SUM2_entry, RingFactorizedRelation<1, int32_t>, 
    PrimaryHashIndex<TMP_SUM2_entry, TMP_SUM2_mapkey0_idxfn>
  > TMP_SUM2_map;
  
  
  struct TMP_SUM3_entry {
    int32_t C; RingFactorizedRelation<1, int32_t> __av; TMP_SUM3_entry* nxt; TMP_SUM3_entry* prv;
  
    explicit TMP_SUM3_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM3_entry(const int32_t c0, const RingFactorizedRelation<1, int32_t>& c1) { C = c0; __av = c1;  }
    TMP_SUM3_entry(const TMP_SUM3_entry& other) : C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM3_entry(const std::vector<std::string>& f, const RingFactorizedRelation<1, int32_t>& v) {
        /* if (f.size() < 1) return; */
        C = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM3_entry& modify(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM3_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM3_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM3_entry& x, const TMP_SUM3_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<TMP_SUM3_entry, RingFactorizedRelation<1, int32_t>, 
    PrimaryHashIndex<TMP_SUM3_entry, TMP_SUM3_mapkey0_idxfn>
  > TMP_SUM3_map;
  
  
  struct TMP_SUM4_entry {
    int32_t C; RingFactorizedRelation<2, int32_t> __av; TMP_SUM4_entry* nxt; TMP_SUM4_entry* prv;
  
    explicit TMP_SUM4_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM4_entry(const int32_t c0, const RingFactorizedRelation<2, int32_t>& c1) { C = c0; __av = c1;  }
    TMP_SUM4_entry(const TMP_SUM4_entry& other) : C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM4_entry(const std::vector<std::string>& f, const RingFactorizedRelation<2, int32_t>& v) {
        /* if (f.size() < 1) return; */
        C = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM4_entry& modify(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM4_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM4_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM4_entry& x, const TMP_SUM4_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<TMP_SUM4_entry, RingFactorizedRelation<2, int32_t>, 
    PrimaryHashIndex<TMP_SUM4_entry, TMP_SUM4_mapkey0_idxfn>
  > TMP_SUM4_map;
  
  
  struct TMP_SUM5_entry {
    int32_t D; int64_t __av; TMP_SUM5_entry* nxt; TMP_SUM5_entry* prv;
  
    explicit TMP_SUM5_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM5_entry(const int32_t c0, const int64_t c1) { D = c0; __av = c1;  }
    TMP_SUM5_entry(const TMP_SUM5_entry& other) : D(other.D), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM5_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 1) return; */
        D = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM5_entry& modify(const int32_t c0) { D = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, D);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM5_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM5_entry& e) {
      size_t h = 0;
      hash_combine(h, e.D);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM5_entry& x, const TMP_SUM5_entry& y) {
      return x.D == y.D;
    }
  };
  
  typedef MultiHashMap<TMP_SUM5_entry, int64_t, 
    PrimaryHashIndex<TMP_SUM5_entry, TMP_SUM5_mapkey0_idxfn>
  > TMP_SUM5_map;
  
  
  struct TMP_SUM6_entry {
    int32_t C; RingFactorizedRelation<2, int32_t> __av; TMP_SUM6_entry* nxt; TMP_SUM6_entry* prv;
  
    explicit TMP_SUM6_entry() : nxt(nullptr), prv(nullptr) { }
    explicit TMP_SUM6_entry(const int32_t c0, const RingFactorizedRelation<2, int32_t>& c1) { C = c0; __av = c1;  }
    TMP_SUM6_entry(const TMP_SUM6_entry& other) : C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    TMP_SUM6_entry(const std::vector<std::string>& f, const RingFactorizedRelation<2, int32_t>& v) {
        /* if (f.size() < 1) return; */
        C = std::stoi(f[0]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE TMP_SUM6_entry& modify(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct TMP_SUM6_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const TMP_SUM6_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const TMP_SUM6_entry& x, const TMP_SUM6_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<TMP_SUM6_entry, RingFactorizedRelation<2, int32_t>, 
    PrimaryHashIndex<TMP_SUM6_entry, TMP_SUM6_mapkey0_idxfn>
  > TMP_SUM6_map;
  
  
  struct DELTA_G1_entry {
    int32_t a; int32_t b; int64_t __av; DELTA_G1_entry* nxt; DELTA_G1_entry* prv;
  
    explicit DELTA_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_G1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { a = c0; b = c1; __av = c2;  }
    DELTA_G1_entry(const DELTA_G1_entry& other) : a(other.a), b(other.b), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        a = std::stoi(f[0]); b = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_G1_entry& modify(const int32_t c0, const int32_t c1) { a = c0; b = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_G1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.a);
      hash_combine(h, e.b);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_G1_entry& x, const DELTA_G1_entry& y) {
      return x.a == y.a && x.b == y.b;
    }
  };
  
  typedef MultiHashMap<DELTA_G1_entry, int64_t, 
    PrimaryHashIndex<DELTA_G1_entry, DELTA_G1_mapkey01_idxfn>
  > DELTA_G1_map;
  
  
  struct DELTA_G2_entry {
    int32_t b; int32_t c; int64_t __av; DELTA_G2_entry* nxt; DELTA_G2_entry* prv;
  
    explicit DELTA_G2_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_G2_entry(const int32_t c0, const int32_t c1, const int64_t c2) { b = c0; c = c1; __av = c2;  }
    DELTA_G2_entry(const DELTA_G2_entry& other) : b(other.b), c(other.c), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_G2_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        b = std::stoi(f[0]); c = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_G2_entry& modify(const int32_t c0, const int32_t c1) { b = c0; c = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_G2_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_G2_entry& e) {
      size_t h = 0;
      hash_combine(h, e.b);
      hash_combine(h, e.c);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_G2_entry& x, const DELTA_G2_entry& y) {
      return x.b == y.b && x.c == y.c;
    }
  };
  
  typedef MultiHashMap<DELTA_G2_entry, int64_t, 
    PrimaryHashIndex<DELTA_G2_entry, DELTA_G2_mapkey01_idxfn>
  > DELTA_G2_map;
  
  
  struct DELTA_G3_entry {
    int32_t c; int32_t d; int64_t __av; DELTA_G3_entry* nxt; DELTA_G3_entry* prv;
  
    explicit DELTA_G3_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_G3_entry(const int32_t c0, const int32_t c1, const int64_t c2) { c = c0; d = c1; __av = c2;  }
    DELTA_G3_entry(const DELTA_G3_entry& other) : c(other.c), d(other.d), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_G3_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        c = std::stoi(f[0]); d = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_G3_entry& modify(const int32_t c0, const int32_t c1) { c = c0; d = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, d);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_G3_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_G3_entry& e) {
      size_t h = 0;
      hash_combine(h, e.c);
      hash_combine(h, e.d);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_G3_entry& x, const DELTA_G3_entry& y) {
      return x.c == y.c && x.d == y.d;
    }
  };
  
  typedef MultiHashMap<DELTA_G3_entry, int64_t, 
    PrimaryHashIndex<DELTA_G3_entry, DELTA_G3_mapkey01_idxfn>
  > DELTA_G3_map;
  
  
  struct DELTA_G4_entry {
    int32_t d; int32_t e; int64_t __av; DELTA_G4_entry* nxt; DELTA_G4_entry* prv;
  
    explicit DELTA_G4_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_G4_entry(const int32_t c0, const int32_t c1, const int64_t c2) { d = c0; e = c1; __av = c2;  }
    DELTA_G4_entry(const DELTA_G4_entry& other) : d(other.d), e(other.e), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_G4_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        d = std::stoi(f[0]); e = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_G4_entry& modify(const int32_t c0, const int32_t c1) { d = c0; e = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, d);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, e);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_G4_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_G4_entry& e) {
      size_t h = 0;
      hash_combine(h, e.d);
      hash_combine(h, e.e);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_G4_entry& x, const DELTA_G4_entry& y) {
      return x.d == y.d && x.e == y.e;
    }
  };
  
  typedef MultiHashMap<DELTA_G4_entry, int64_t, 
    PrimaryHashIndex<DELTA_G4_entry, DELTA_G4_mapkey01_idxfn>
  > DELTA_G4_map;

  

  /* Defines top-level materialized views */
  struct tlq_t {
    struct timeval t0, t; 
    size_t tT, tN, tS;
  
    tlq_t(): tN(0), tS(0) , V_C_GGGG1(RingFactorizedRelation<0, int32_t>()) { 
      gettimeofday(&t0, NULL); 
    }
  
    /* Serialization code */
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << "\n";
      const RingFactorizedRelation<0, int32_t>& _V_C_GGGG1 = get_V_C_GGGG1();
      dbtoaster::serialize_nvp_tabbed(ar, STRING(V_C_GGGG1), _V_C_GGGG1, "\t");
      
      ar << "\n";
      const V_B_GG1_map& _V_B_GG1 = get_V_B_GG1();
      dbtoaster::serialize_nvp_tabbed(ar, STRING(V_B_GG1), _V_B_GG1, "\t");
      
      ar << "\n";
      const V_D_GG1_map& _V_D_GG1 = get_V_D_GG1();
      dbtoaster::serialize_nvp_tabbed(ar, STRING(V_D_GG1), _V_D_GG1, "\t");
    }
  
    /* Functions returning / computing the results of top level queries */
    const RingFactorizedRelation<0, int32_t>& get_V_C_GGGG1() const {
      return V_C_GGGG1;
    }
    
    const V_B_GG1_map& get_V_B_GG1() const {
      return V_B_GG1;
    }
    
    const V_D_GG1_map& get_V_D_GG1() const {
      return V_D_GG1;
    }
  
  protected:
    /* Data structures used for storing / computing top-level queries */
    RingFactorizedRelation<0, int32_t> V_C_GGGG1;
    V_B_GG1_map V_B_GG1;
    V_D_GG1_map V_D_GG1;
    
  };

  /* Contains materialized views and processing (IVM) logic */
  struct data_t : tlq_t {
  
    data_t(): tlq_t() {
      
      
    }
  
    
  
    
  
    /* Trigger functions for table relations */
    
    
    /* Trigger functions for stream relations */
    void on_batch_update_G1(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM1.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& a = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& b = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v1 = chunk.payload[i];
          TMP_SUM1.addOrDelOnZero(se1.modify(b), v1);
        }
      }
      
      TMP_SUM2.clear();
      { //foreach
        TMP_SUM1_entry* e2 = TMP_SUM1.head;
        while (e2) {
          int32_t b = e2->B;
          int64_t v2 = e2->__av;
          { //slice
            const LinkedNode<V_G2_G1_entry>* n1 = static_cast<const LinkedNode<V_G2_G1_entry>*>(V_G2_G1.slice(se3.modify0(b), 0));
            V_G2_G1_entry* e3;
            while (n1) {
              e3 = n1->obj;
              int32_t c = e3->C;
              int64_t v3 = e3->__av;
              TMP_SUM2.addOrDelOnZero(se2.modify(c), ((v2 * v3) * Ulift<1>(b)));
              n1 = n1->next;
            }
          }
          e2 = e2->nxt;
        }
      }
      
      { //foreach
        TMP_SUM2_entry* e4 = TMP_SUM2.head;
        while (e4) {
          int32_t c = e4->C;
          RingFactorizedRelation<1, int32_t>& v4 = e4->__av;
          V_C_GGGG1 += ((v4 * V_D_GG1.getValueOrDefault(se5.modify(c))) * Ulift<0>(c));
          e4 = e4->nxt;
        }
      }
      
      { //foreach
        TMP_SUM2_entry* e5 = TMP_SUM2.head;
        while (e5) {
          int32_t c = e5->C;
          RingFactorizedRelation<1, int32_t>& v5 = e5->__av;
          V_B_GG1.addOrDelOnZero(se6.modify(c), v5);
          e5 = e5->nxt;
        }
      }
      
      { //foreach
        TMP_SUM1_entry* e6 = TMP_SUM1.head;
        while (e6) {
          int32_t b = e6->B;
          int64_t v6 = e6->__av;
          V_A_G1.addOrDelOnZero(se7.modify(b), v6);
          e6 = e6->nxt;
        }
      }
    }
    
    
    void on_batch_update_G2(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM3.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& b = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v7 = chunk.payload[i];
          TMP_SUM3.addOrDelOnZero(se8.modify(c), ((v7 * V_A_G1.getValueOrDefault(se9.modify(b))) * Ulift<1>(b)));
        }
      }
      
      { //foreach
        TMP_SUM3_entry* e8 = TMP_SUM3.head;
        while (e8) {
          int32_t c = e8->C;
          RingFactorizedRelation<1, int32_t>& v8 = e8->__av;
          V_C_GGGG1 += ((v8 * V_D_GG1.getValueOrDefault(se11.modify(c))) * Ulift<0>(c));
          e8 = e8->nxt;
        }
      }
      
      { //foreach
        TMP_SUM3_entry* e9 = TMP_SUM3.head;
        while (e9) {
          int32_t c = e9->C;
          RingFactorizedRelation<1, int32_t>& v9 = e9->__av;
          V_B_GG1.addOrDelOnZero(se12.modify(c), v9);
          e9 = e9->nxt;
        }
      }
      
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& b = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v10 = chunk.payload[i];
          V_G2_G1.addOrDelOnZero(se13.modify(b, c), v10);
        }
      }
    }
    
    
    void on_batch_update_G3(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM4.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& d = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v11 = chunk.payload[i];
          TMP_SUM4.addOrDelOnZero(se14.modify(c), ((v11 * V_E_G1.getValueOrDefault(se15.modify(d))) * Ulift<2>(d)));
        }
      }
      
      { //foreach
        TMP_SUM4_entry* e12 = TMP_SUM4.head;
        while (e12) {
          int32_t c = e12->C;
          RingFactorizedRelation<2, int32_t>& v12 = e12->__av;
          V_C_GGGG1 += ((v12 * V_B_GG1.getValueOrDefault(se17.modify(c))) * Ulift<0>(c));
          e12 = e12->nxt;
        }
      }
      
      { //foreach
        TMP_SUM4_entry* e13 = TMP_SUM4.head;
        while (e13) {
          int32_t c = e13->C;
          RingFactorizedRelation<2, int32_t>& v13 = e13->__av;
          V_D_GG1.addOrDelOnZero(se18.modify(c), v13);
          e13 = e13->nxt;
        }
      }
      
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& d = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v14 = chunk.payload[i];
          V_G3_G1.addOrDelOnZero(se19.modify(c, d), v14);
        }
      }
    }
    
    
    void on_batch_update_G4(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      TMP_SUM5.clear();
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& d = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& e = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v15 = chunk.payload[i];
          TMP_SUM5.addOrDelOnZero(se20.modify(d), v15);
        }
      }
      
      TMP_SUM6.clear();
      { //foreach
        TMP_SUM5_entry* e16 = TMP_SUM5.head;
        while (e16) {
          int32_t d = e16->D;
          int64_t v16 = e16->__av;
          { //slice
            const LinkedNode<V_G3_G1_entry>* n2 = static_cast<const LinkedNode<V_G3_G1_entry>*>(V_G3_G1.slice(se22.modify1(d), 0));
            V_G3_G1_entry* e17;
            while (n2) {
              e17 = n2->obj;
              int32_t c = e17->C;
              int64_t v17 = e17->__av;
              TMP_SUM6.addOrDelOnZero(se21.modify(c), ((v16 * v17) * Ulift<2>(d)));
              n2 = n2->next;
            }
          }
          e16 = e16->nxt;
        }
      }
      
      { //foreach
        TMP_SUM6_entry* e18 = TMP_SUM6.head;
        while (e18) {
          int32_t c = e18->C;
          RingFactorizedRelation<2, int32_t>& v18 = e18->__av;
          V_C_GGGG1 += ((v18 * V_B_GG1.getValueOrDefault(se24.modify(c))) * Ulift<0>(c));
          e18 = e18->nxt;
        }
      }
      
      { //foreach
        TMP_SUM6_entry* e19 = TMP_SUM6.head;
        while (e19) {
          int32_t c = e19->C;
          RingFactorizedRelation<2, int32_t>& v19 = e19->__av;
          V_D_GG1.addOrDelOnZero(se25.modify(c), v19);
          e19 = e19->nxt;
        }
      }
      
      { //foreach
        TMP_SUM5_entry* e20 = TMP_SUM5.head;
        while (e20) {
          int32_t d = e20->D;
          int64_t v20 = e20->__av;
          V_E_G1.addOrDelOnZero(se26.modify(d), v20);
          e20 = e20->nxt;
        }
      }
    }
    
    
    void on_system_ready_event() {
      
    }
  
  private:
    
      /* Preallocated map entries (to avoid recreation of temporary objects) */
      TMP_SUM1_entry se1;
      TMP_SUM2_entry se2;
      V_G2_G1_entry se3;
      V_D_GG1_entry se5;
      V_B_GG1_entry se6;
      V_A_G1_entry se7;
      TMP_SUM3_entry se8;
      V_A_G1_entry se9;
      V_D_GG1_entry se11;
      V_B_GG1_entry se12;
      V_G2_G1_entry se13;
      TMP_SUM4_entry se14;
      V_E_G1_entry se15;
      V_B_GG1_entry se17;
      V_D_GG1_entry se18;
      V_G3_G1_entry se19;
      TMP_SUM5_entry se20;
      TMP_SUM6_entry se21;
      V_G3_G1_entry se22;
      V_B_GG1_entry se24;
      V_D_GG1_entry se25;
      V_E_G1_entry se26;
    
      
    
      /* Data structures used for storing materialized views */
      V_A_G1_map V_A_G1;
      V_G2_G1_map V_G2_G1;
      V_E_G1_map V_E_G1;
      V_G3_G1_map V_G3_G1;
      TMP_SUM1_map TMP_SUM1;
      TMP_SUM2_map TMP_SUM2;
      TMP_SUM3_map TMP_SUM3;
      TMP_SUM4_map TMP_SUM4;
      TMP_SUM5_map TMP_SUM5;
      TMP_SUM6_map TMP_SUM6;
      DELTA_G1_map DELTA_G1;
      DELTA_G2_map DELTA_G2;
      DELTA_G3_map DELTA_G3;
      DELTA_G4_map DELTA_G4;
    
      
    
  };

  

  namespace Config {
    static const std::vector<DataSourceConfig> DataSources = {
    {
      "G1",
      true,
      DataSourceType::CSV,
      "unused.g1",
      // schema
      {{"a", PrimitiveType::INT32}, {"b", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_G1(chunk);
      }
    },
    {
      "G2",
      true,
      DataSourceType::CSV,
      "unused.g2",
      // schema
      {{"b", PrimitiveType::INT32}, {"c", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_G2(chunk);
      }
    },
    {
      "G3",
      true,
      DataSourceType::CSV,
      "unused.g3",
      // schema
      {{"c", PrimitiveType::INT32}, {"d", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_G3(chunk);
      }
    },
    {
      "G4",
      true,
      DataSourceType::CSV,
      "unused.g4",
      // schema
      {{"d", PrimitiveType::INT32}, {"e", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_G4(chunk);
      }
    }
    };
  }

}