#include <sys/time.h>
#include <vector>
#include "dbtoaster/functions.hpp"
#include "dbtoaster/hash.hpp"
#include "dbtoaster/macro.hpp"
#include "dbtoaster/mmap.hpp"
#include "dbtoaster/serialization.hpp"
#include "dbtoaster/types.hpp"
#include "common.hpp"



#define RELATION_G1_DYNAMIC
#define RELATION_G2_DYNAMIC
#define RELATION_G3_DYNAMIC

namespace dbtoaster {

  /* Definitions of maps used for storing materialized views. */
  struct G1_entry {
    int32_t a; int32_t b; int64_t __av; G1_entry* nxt; G1_entry* prv;
  
    explicit G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit G1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { a = c0; b = c1; __av = c2;  }
    G1_entry(const G1_entry& other) : a(other.a), b(other.b), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        a = std::stoi(f[0]); b = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct G2_entry {
    int32_t b; int32_t c; int64_t __av; G2_entry* nxt; G2_entry* prv;
  
    explicit G2_entry() : nxt(nullptr), prv(nullptr) { }
    explicit G2_entry(const int32_t c0, const int32_t c1, const int64_t c2) { b = c0; c = c1; __av = c2;  }
    G2_entry(const G2_entry& other) : b(other.b), c(other.c), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    G2_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        b = std::stoi(f[0]); c = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct G3_entry {
    int32_t c; int32_t d; int64_t __av; G3_entry* nxt; G3_entry* prv;
  
    explicit G3_entry() : nxt(nullptr), prv(nullptr) { }
    explicit G3_entry(const int32_t c0, const int32_t c1, const int64_t c2) { c = c0; d = c1; __av = c2;  }
    G3_entry(const G3_entry& other) : c(other.c), d(other.d), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    G3_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        c = std::stoi(f[0]); d = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, d);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  struct V_B_GGG1_entry {
    int32_t A; int32_t B; int32_t C; int32_t D; int64_t __av; V_B_GGG1_entry* nxt; V_B_GGG1_entry* prv;
  
    explicit V_B_GGG1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_B_GGG1_entry(const int32_t c0, const int32_t c1, const int32_t c2, const int32_t c3, const int64_t c4) { A = c0; B = c1; C = c2; D = c3; __av = c4;  }
    V_B_GGG1_entry(const V_B_GGG1_entry& other) : A(other.A), B(other.B), C(other.C), D(other.D), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_B_GGG1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 4) return; */
        A = std::stoi(f[0]); B = std::stoi(f[1]); C = std::stoi(f[2]); D = std::stoi(f[3]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_B_GGG1_entry& modify(const int32_t c0, const int32_t c1, const int32_t c2, const int32_t c3) { A = c0; B = c1; C = c2; D = c3;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, A);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, D);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_B_GGG1_mapkey0123_idxfn {
    FORCE_INLINE static size_t hash(const V_B_GGG1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.A);
      hash_combine(h, e.B);
      hash_combine(h, e.C);
      hash_combine(h, e.D);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_B_GGG1_entry& x, const V_B_GGG1_entry& y) {
      return x.A == y.A && x.B == y.B && x.C == y.C && x.D == y.D;
    }
  };
  
  typedef MultiHashMap<V_B_GGG1_entry, int64_t, 
    PrimaryHashIndex<V_B_GGG1_entry, V_B_GGG1_mapkey0123_idxfn>
  > V_B_GGG1_map;
  
  
  struct V_A_G1_entry {
    int32_t A; int32_t B; int64_t __av; V_A_G1_entry* nxt; V_A_G1_entry* prv;
  
    explicit V_A_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_A_G1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { A = c0; B = c1; __av = c2;  }
    V_A_G1_entry(const V_A_G1_entry& other) : A(other.A), B(other.B), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_A_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        A = std::stoi(f[0]); B = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_A_G1_entry& modify(const int32_t c0, const int32_t c1) { A = c0; B = c1;  return *this; }
    FORCE_INLINE V_A_G1_entry& modify1(const int32_t c1) { B = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, A);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_A_G1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const V_A_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.A);
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_A_G1_entry& x, const V_A_G1_entry& y) {
      return x.A == y.A && x.B == y.B;
    }
  };
  
  struct V_A_G1_mapkey1_idxfn {
    FORCE_INLINE static size_t hash(const V_A_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_A_G1_entry& x, const V_A_G1_entry& y) {
      return x.B == y.B;
    }
  };
  
  typedef MultiHashMap<V_A_G1_entry, int64_t, 
    PrimaryHashIndex<V_A_G1_entry, V_A_G1_mapkey01_idxfn>,
    SecondaryHashIndex<V_A_G1_entry, V_A_G1_mapkey1_idxfn>
  > V_A_G1_map;
  
  
  struct V_C_GG1_entry {
    int32_t C; int32_t D; int32_t B; int64_t __av; V_C_GG1_entry* nxt; V_C_GG1_entry* prv;
  
    explicit V_C_GG1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_C_GG1_entry(const int32_t c0, const int32_t c1, const int32_t c2, const int64_t c3) { C = c0; D = c1; B = c2; __av = c3;  }
    V_C_GG1_entry(const V_C_GG1_entry& other) : C(other.C), D(other.D), B(other.B), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_C_GG1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 3) return; */
        C = std::stoi(f[0]); D = std::stoi(f[1]); B = std::stoi(f[2]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_C_GG1_entry& modify(const int32_t c0, const int32_t c1, const int32_t c2) { C = c0; D = c1; B = c2;  return *this; }
    FORCE_INLINE V_C_GG1_entry& modify2(const int32_t c2) { B = c2;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, D);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_C_GG1_mapkey012_idxfn {
    FORCE_INLINE static size_t hash(const V_C_GG1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      hash_combine(h, e.D);
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_C_GG1_entry& x, const V_C_GG1_entry& y) {
      return x.C == y.C && x.D == y.D && x.B == y.B;
    }
  };
  
  struct V_C_GG1_mapkey2_idxfn {
    FORCE_INLINE static size_t hash(const V_C_GG1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_C_GG1_entry& x, const V_C_GG1_entry& y) {
      return x.B == y.B;
    }
  };
  
  typedef MultiHashMap<V_C_GG1_entry, int64_t, 
    PrimaryHashIndex<V_C_GG1_entry, V_C_GG1_mapkey012_idxfn>,
    SecondaryHashIndex<V_C_GG1_entry, V_C_GG1_mapkey2_idxfn>
  > V_C_GG1_map;
  
  
  struct V_D_G1_entry {
    int32_t C; int32_t D; int64_t __av; V_D_G1_entry* nxt; V_D_G1_entry* prv;
  
    explicit V_D_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_D_G1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { C = c0; D = c1; __av = c2;  }
    V_D_G1_entry(const V_D_G1_entry& other) : C(other.C), D(other.D), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_D_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        C = std::stoi(f[0]); D = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_D_G1_entry& modify(const int32_t c0, const int32_t c1) { C = c0; D = c1;  return *this; }
    FORCE_INLINE V_D_G1_entry& modify0(const int32_t c0) { C = c0;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, D);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_D_G1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const V_D_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      hash_combine(h, e.D);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_D_G1_entry& x, const V_D_G1_entry& y) {
      return x.C == y.C && x.D == y.D;
    }
  };
  
  struct V_D_G1_mapkey0_idxfn {
    FORCE_INLINE static size_t hash(const V_D_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_D_G1_entry& x, const V_D_G1_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<V_D_G1_entry, int64_t, 
    PrimaryHashIndex<V_D_G1_entry, V_D_G1_mapkey01_idxfn>,
    SecondaryHashIndex<V_D_G1_entry, V_D_G1_mapkey0_idxfn>
  > V_D_G1_map;
  
  
  struct V_G2_G1_entry {
    int32_t B; int32_t C; int64_t __av; V_G2_G1_entry* nxt; V_G2_G1_entry* prv;
  
    explicit V_G2_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit V_G2_G1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { B = c0; C = c1; __av = c2;  }
    V_G2_G1_entry(const V_G2_G1_entry& other) : B(other.B), C(other.C), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    V_G2_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        B = std::stoi(f[0]); C = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE V_G2_G1_entry& modify(const int32_t c0, const int32_t c1) { B = c0; C = c1;  return *this; }
    FORCE_INLINE V_G2_G1_entry& modify1(const int32_t c1) { C = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, B);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, C);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct V_G2_G1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const V_G2_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.B);
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_G2_G1_entry& x, const V_G2_G1_entry& y) {
      return x.B == y.B && x.C == y.C;
    }
  };
  
  struct V_G2_G1_mapkey1_idxfn {
    FORCE_INLINE static size_t hash(const V_G2_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.C);
      return h;
    }
    
    FORCE_INLINE static bool equals(const V_G2_G1_entry& x, const V_G2_G1_entry& y) {
      return x.C == y.C;
    }
  };
  
  typedef MultiHashMap<V_G2_G1_entry, int64_t, 
    PrimaryHashIndex<V_G2_G1_entry, V_G2_G1_mapkey01_idxfn>,
    SecondaryHashIndex<V_G2_G1_entry, V_G2_G1_mapkey1_idxfn>
  > V_G2_G1_map;
  
  
  struct DELTA_G1_entry {
    int32_t a; int32_t b; int64_t __av; DELTA_G1_entry* nxt; DELTA_G1_entry* prv;
  
    explicit DELTA_G1_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_G1_entry(const int32_t c0, const int32_t c1, const int64_t c2) { a = c0; b = c1; __av = c2;  }
    DELTA_G1_entry(const DELTA_G1_entry& other) : a(other.a), b(other.b), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_G1_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        a = std::stoi(f[0]); b = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_G1_entry& modify(const int32_t c0, const int32_t c1) { a = c0; b = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, a);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_G1_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_G1_entry& e) {
      size_t h = 0;
      hash_combine(h, e.a);
      hash_combine(h, e.b);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_G1_entry& x, const DELTA_G1_entry& y) {
      return x.a == y.a && x.b == y.b;
    }
  };
  
  typedef MultiHashMap<DELTA_G1_entry, int64_t, 
    PrimaryHashIndex<DELTA_G1_entry, DELTA_G1_mapkey01_idxfn>
  > DELTA_G1_map;
  
  
  struct DELTA_G2_entry {
    int32_t b; int32_t c; int64_t __av; DELTA_G2_entry* nxt; DELTA_G2_entry* prv;
  
    explicit DELTA_G2_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_G2_entry(const int32_t c0, const int32_t c1, const int64_t c2) { b = c0; c = c1; __av = c2;  }
    DELTA_G2_entry(const DELTA_G2_entry& other) : b(other.b), c(other.c), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_G2_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        b = std::stoi(f[0]); c = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_G2_entry& modify(const int32_t c0, const int32_t c1) { b = c0; c = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, b);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_G2_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_G2_entry& e) {
      size_t h = 0;
      hash_combine(h, e.b);
      hash_combine(h, e.c);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_G2_entry& x, const DELTA_G2_entry& y) {
      return x.b == y.b && x.c == y.c;
    }
  };
  
  typedef MultiHashMap<DELTA_G2_entry, int64_t, 
    PrimaryHashIndex<DELTA_G2_entry, DELTA_G2_mapkey01_idxfn>
  > DELTA_G2_map;
  
  
  struct DELTA_G3_entry {
    int32_t c; int32_t d; int64_t __av; DELTA_G3_entry* nxt; DELTA_G3_entry* prv;
  
    explicit DELTA_G3_entry() : nxt(nullptr), prv(nullptr) { }
    explicit DELTA_G3_entry(const int32_t c0, const int32_t c1, const int64_t c2) { c = c0; d = c1; __av = c2;  }
    DELTA_G3_entry(const DELTA_G3_entry& other) : c(other.c), d(other.d), __av(other.__av), nxt(nullptr), prv(nullptr) { }
    DELTA_G3_entry(const std::vector<std::string>& f, const int64_t v) {
        /* if (f.size() < 2) return; */
        c = std::stoi(f[0]); d = std::stoi(f[1]); __av = v; nxt = nullptr; prv = nullptr;
    }
    
    FORCE_INLINE DELTA_G3_entry& modify(const int32_t c0, const int32_t c1) { c = c0; d = c1;  return *this; }
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, c);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, d);
      ar << ELEM_SEPARATOR;
      DBT_SERIALIZATION_NVP(ar, __av);
    }
  };
  
  struct DELTA_G3_mapkey01_idxfn {
    FORCE_INLINE static size_t hash(const DELTA_G3_entry& e) {
      size_t h = 0;
      hash_combine(h, e.c);
      hash_combine(h, e.d);
      return h;
    }
    
    FORCE_INLINE static bool equals(const DELTA_G3_entry& x, const DELTA_G3_entry& y) {
      return x.c == y.c && x.d == y.d;
    }
  };
  
  typedef MultiHashMap<DELTA_G3_entry, int64_t, 
    PrimaryHashIndex<DELTA_G3_entry, DELTA_G3_mapkey01_idxfn>
  > DELTA_G3_map;

  

  /* Defines top-level materialized views */
  struct tlq_t {
    struct timeval t0, t; 
    size_t tT, tN, tS;
  
    tlq_t(): tN(0), tS(0)  { 
      gettimeofday(&t0, NULL); 
    }
  
    /* Serialization code */
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version) const {
      ar << "\n";
      const V_B_GGG1_map& _V_B_GGG1 = get_V_B_GGG1();
      dbtoaster::serialize_nvp_tabbed(ar, STRING(V_B_GGG1), _V_B_GGG1, "\t");
    }
  
    /* Functions returning / computing the results of top level queries */
    const V_B_GGG1_map& get_V_B_GGG1() const {
      return V_B_GGG1;
    }
  
  protected:
    /* Data structures used for storing / computing top-level queries */
    V_B_GGG1_map V_B_GGG1;
    
  };

  /* Contains materialized views and processing (IVM) logic */
  struct data_t : tlq_t {
  
    data_t(): tlq_t() {
      
      
    }
  
    
  
    
  
    /* Trigger functions for table relations */
    
    
    /* Trigger functions for stream relations */
    void on_batch_update_G1(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& a = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& b = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v1 = chunk.payload[i];
          { //slice
            const LinkedNode<V_C_GG1_entry>* n1 = static_cast<const LinkedNode<V_C_GG1_entry>*>(V_C_GG1.slice(se2.modify2(b), 0));
            V_C_GG1_entry* e2;
            while (n1) {
              e2 = n1->obj;
              int32_t c = e2->C;
              int32_t d = e2->D;
              int64_t v2 = e2->__av;
              V_B_GGG1.addOrDelOnZero(se1.modify(a, b, c, d), (v1 * v2));
              n1 = n1->next;
            }
          }
        }
      }
      
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& a = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& b = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v3 = chunk.payload[i];
          V_A_G1.addOrDelOnZero(se3.modify(a, b), v3);
        }
      }
    }
    
    
    void on_batch_update_G2(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& b = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v4 = chunk.payload[i];
          { //slice
            const LinkedNode<V_D_G1_entry>* n3 = static_cast<const LinkedNode<V_D_G1_entry>*>(V_D_G1.slice(se6.modify0(c), 0));
            V_D_G1_entry* e5;
            while (n3) {
              e5 = n3->obj;
              int32_t d = e5->D;
              int64_t v5 = e5->__av;
              { //slice
                const LinkedNode<V_A_G1_entry>* n2 = static_cast<const LinkedNode<V_A_G1_entry>*>(V_A_G1.slice(se5.modify1(b), 0));
                V_A_G1_entry* e6;
                while (n2) {
                  e6 = n2->obj;
                  int32_t a = e6->A;
                  int64_t v6 = e6->__av;
                  V_B_GGG1.addOrDelOnZero(se4.modify(a, b, c, d), ((v4 * v5) * v6));
                  n2 = n2->next;
                }
              }
              n3 = n3->next;
            }
          }
        }
      }
      
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& b = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v7 = chunk.payload[i];
          { //slice
            const LinkedNode<V_D_G1_entry>* n4 = static_cast<const LinkedNode<V_D_G1_entry>*>(V_D_G1.slice(se8.modify0(c), 0));
            V_D_G1_entry* e8;
            while (n4) {
              e8 = n4->obj;
              int32_t d = e8->D;
              int64_t v8 = e8->__av;
              V_C_GG1.addOrDelOnZero(se7.modify(c, d, b), (v7 * v8));
              n4 = n4->next;
            }
          }
        }
      }
      
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& b = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v9 = chunk.payload[i];
          V_G2_G1.addOrDelOnZero(se9.modify(b, c), v9);
        }
      }
    }
    
    
    void on_batch_update_G3(const DataChunk& chunk) {
      size_t batchSize = chunk.row_count;
      
      tN += batchSize;
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& d = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v10 = chunk.payload[i];
          { //slice
            const LinkedNode<V_G2_G1_entry>* n6 = static_cast<const LinkedNode<V_G2_G1_entry>*>(V_G2_G1.slice(se12.modify1(c), 0));
            V_G2_G1_entry* e11;
            while (n6) {
              e11 = n6->obj;
              int32_t b = e11->B;
              int64_t v11 = e11->__av;
              { //slice
                const LinkedNode<V_A_G1_entry>* n5 = static_cast<const LinkedNode<V_A_G1_entry>*>(V_A_G1.slice(se11.modify1(b), 0));
                V_A_G1_entry* e12;
                while (n5) {
                  e12 = n5->obj;
                  int32_t a = e12->A;
                  int64_t v12 = e12->__av;
                  V_B_GGG1.addOrDelOnZero(se10.modify(a, b, c, d), ((v10 * v11) * v12));
                  n5 = n5->next;
                }
              }
              n6 = n6->next;
            }
          }
        }
      }
      
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& d = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v13 = chunk.payload[i];
          { //slice
            const LinkedNode<V_G2_G1_entry>* n7 = static_cast<const LinkedNode<V_G2_G1_entry>*>(V_G2_G1.slice(se14.modify1(c), 0));
            V_G2_G1_entry* e14;
            while (n7) {
              e14 = n7->obj;
              int32_t b = e14->B;
              int64_t v14 = e14->__av;
              V_C_GG1.addOrDelOnZero(se13.modify(c, d, b), (v13 * v14));
              n7 = n7->next;
            }
          }
        }
      }
      
      { //foreach
        for (size_t i = 0; i < chunk.row_count; ++i) {
          const auto& c = static_cast<Column<int32_t>*>(chunk.cols[0].get())->data[i];
          const auto& d = static_cast<Column<int32_t>*>(chunk.cols[1].get())->data[i];
          const auto& v15 = chunk.payload[i];
          V_D_G1.addOrDelOnZero(se15.modify(c, d), v15);
        }
      }
    }
    
    
    void on_system_ready_event() {
      
    }
  
  private:
    
      /* Preallocated map entries (to avoid recreation of temporary objects) */
      V_B_GGG1_entry se1;
      V_C_GG1_entry se2;
      V_A_G1_entry se3;
      V_B_GGG1_entry se4;
      V_A_G1_entry se5;
      V_D_G1_entry se6;
      V_C_GG1_entry se7;
      V_D_G1_entry se8;
      V_G2_G1_entry se9;
      V_B_GGG1_entry se10;
      V_A_G1_entry se11;
      V_G2_G1_entry se12;
      V_C_GG1_entry se13;
      V_G2_G1_entry se14;
      V_D_G1_entry se15;
    
      
    
      /* Data structures used for storing materialized views */
      V_A_G1_map V_A_G1;
      V_C_GG1_map V_C_GG1;
      V_D_G1_map V_D_G1;
      V_G2_G1_map V_G2_G1;
      DELTA_G1_map DELTA_G1;
      DELTA_G2_map DELTA_G2;
      DELTA_G3_map DELTA_G3;
    
      
    
  };

  

  namespace Config {
    static const std::vector<DataSourceConfig> DataSources = {
    {
      "G1",
      true,
      DataSourceType::CSV,
      "unused.g1",
      // schema
      {{"a", PrimitiveType::INT32}, {"b", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_G1(chunk);
      }
    },
    {
      "G2",
      true,
      DataSourceType::CSV,
      "unused.g2",
      // schema
      {{"b", PrimitiveType::INT32}, {"c", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_G2(chunk);
      }
    },
    {
      "G3",
      true,
      DataSourceType::CSV,
      "unused.g3",
      // schema
      {{"c", PrimitiveType::INT32}, {"d", PrimitiveType::INT32}},
      // options
      {},
      [](void* ctx, const DataChunk& chunk) {
        data_t* d = static_cast<data_t*>(ctx);
        d->on_batch_update_G3(chunk);
      }
    }
    };
  }

}